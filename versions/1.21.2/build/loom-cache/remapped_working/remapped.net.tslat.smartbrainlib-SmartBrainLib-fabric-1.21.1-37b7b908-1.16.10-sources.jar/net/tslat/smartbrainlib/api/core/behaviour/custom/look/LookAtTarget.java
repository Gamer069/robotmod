package net.tslat.smartbrainlib.api.core.behaviour.custom.look;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.ai.brain.EntityLookTarget;
import net.minecraft.entity.ai.brain.LookTarget;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtils;

import java.util.List;

/**
 * Look at the look target for as long as it is present
 * <p>
 * Additionally, invalidates the look target if it is an {@link EntityLookTarget} and the entity has expired
 *
 * @param <E> The entity
 */
public class LookAtTarget<E extends MobEntity> extends ExtendedBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(1).hasMemory(MemoryModuleType.LOOK_TARGET);

	public LookAtTarget() {
		noTimeout();
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean checkExtraStartConditions(ServerWorld level, E entity) {
		return testAndInvalidateLookTarget(entity);
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		return testAndInvalidateLookTarget(entity);
	}

	@Override
	protected void tick(E entity) {
		BrainUtils.withMemory(entity, MemoryModuleType.LOOK_TARGET, target -> entity.getLookControl().lookAt(target.getPos()));
	}

	/**
	 * Check and expire the look target if it is no longer valid
	 *
	 * @return true if the look target is valid
	 */
	protected boolean testAndInvalidateLookTarget(E entity) {
		LookTarget lookTarget = BrainUtils.getMemory(entity, MemoryModuleType.LOOK_TARGET);

		if (lookTarget == null)
			return false;

		if (lookTarget instanceof EntityLookTarget entityTracker && (!entityTracker.getEntity().isAlive() || entityTracker.getEntity().isSpectator())) {
			BrainUtils.clearMemory(entity, MemoryModuleType.LOOK_TARGET);

			return false;
		}

		return true;
	}
}
