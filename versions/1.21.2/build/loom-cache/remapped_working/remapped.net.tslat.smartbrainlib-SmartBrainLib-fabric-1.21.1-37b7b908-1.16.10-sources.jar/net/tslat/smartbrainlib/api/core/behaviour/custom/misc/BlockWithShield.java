package net.tslat.smartbrainlib.api.core.behaviour.custom.misc;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.item.consume.UseAction;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;

import java.util.List;
import java.util.function.Predicate;

/**
 * Makes the entity use (block) using a shield if it's currently in the entity's hands
 */
public class BlockWithShield<E extends LivingEntity> extends ExtendedBehaviour<E> {
	protected Hand hand = Hand.MAIN_HAND;

	protected Predicate<E> stopCondition = entity -> false;

	/**
	 * Sets the condition for when the entity should stop blocking.<br>
	 * Deprecated, use {@link ExtendedBehaviour#stopIf}
	 * @param predicate The predicate
	 * @return this
	 */
	@Deprecated(forRemoval = true)
	public BlockWithShield<E> stopWhen(Predicate<E> predicate) {
		this.stopCondition = predicate;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return List.of();
	}

	@Override
	protected boolean shouldRun(ServerWorld level, E entity) {
		if (entity.getMainHandStack().getUseAction() == UseAction.BLOCK) {
			this.hand = Hand.MAIN_HAND;

			return true;
		}
		else if (entity.getOffHandStack().getUseAction() == UseAction.BLOCK) {
			this.hand = Hand.OFF_HAND;

			return true;
		}

		return false;
	}

	@Override
	protected void start(E entity) {
		entity.setCurrentHand(this.hand);
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		if (!entity.isUsingItem())
			return false;

		if (!(entity.getActiveItem().getUseAction() == UseAction.BLOCK))
			return false;

		return !this.stopCondition.test(entity);
	}

	@Override
	protected void stop(E entity) {
		if (entity.getActiveItem().getUseAction() == UseAction.BLOCK)
			entity.clearActiveItem();
	}
}