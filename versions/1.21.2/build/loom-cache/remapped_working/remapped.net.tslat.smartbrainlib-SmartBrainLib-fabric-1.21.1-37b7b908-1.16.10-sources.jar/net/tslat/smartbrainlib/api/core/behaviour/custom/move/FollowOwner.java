package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.TameableEntity;

/**
 * A movement behaviour for automatically following the owner of a {@link TameableEntity TameableAnimal}
 *
 * @param <E> The owner of the brain
 */
public class FollowOwner<E extends TameableEntity> extends FollowEntity<E, LivingEntity> {
	protected LivingEntity owner = null;

	public FollowOwner() {
		following(this::getOwner);
		teleportToTargetAfter(12);
	}

	protected LivingEntity getOwner(E entity) {
		if (this.owner != null && (this.owner.isRemoved() || !this.owner.getUuid().equals(entity.getOwnerUuid())))
			this.owner = null;

		if (this.owner == null)
			this.owner = entity.getOwner();

		return this.owner;
	}
}