package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.WalkTarget;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Sets the {@link MemoryModuleType#WALK_TARGET walk target} to a safe position if caught in the sun. <br>
 * Defaults:
 * <ul>
 *     <li>Only if not currently fighting something</li>
 *     <li>Only if already burning from the sun</li>
 * </ul>
 * @param <E> The entity
 */
public class EscapeSun<E extends PathAwareEntity> extends ExtendedBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(2).noMemory(MemoryModuleType.ATTACK_TARGET).usesMemory(MemoryModuleType.WALK_TARGET);

	protected float speedModifier = 1;

	protected Vec3d hidePos = null;

	public EscapeSun() {
		noTimeout();
	}

	/**
	 * Set the movespeed modifier for when the entity tries to escape the sun
	 * @param speedMod The speed modifier
	 * @return this
	 */
	public EscapeSun<E> speedModifier(float speedMod) {
		this.speedModifier = speedMod;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean checkExtraStartConditions(ServerWorld level, E entity) {
		if (!level.isDay() || !entity.isOnFire() || !level.isSkyVisible(entity.getBlockPos()))
			return false;

		if (!entity.getEquippedStack(EquipmentSlot.HEAD).isEmpty())
			return false;

		this.hidePos = getHidePos(entity);

		return this.hidePos != null;
	}

	@Override
	protected void start(E entity) {
		BrainUtils.setMemory(entity, MemoryModuleType.WALK_TARGET, new WalkTarget(this.hidePos, this.speedModifier, 0));
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		if (this.hidePos == null)
			return false;

		WalkTarget walkTarget = BrainUtils.getMemory(entity, MemoryModuleType.WALK_TARGET);

		if (walkTarget == null)
			return false;

		return walkTarget.getLookTarget().getBlockPos().equals(BlockPos.ofFloored(this.hidePos)) && !entity.getNavigation().isIdle();
	}

	@Override
	protected void stop(E entity) {
		this.hidePos = null;
	}

	@Nullable
	protected Vec3d getHidePos(E entity) {
		Random randomsource = entity.getRandom();
		BlockPos entityPos = entity.getBlockPos();

		for(int i = 0; i < 10; ++i) {
			BlockPos hidePos = entityPos.add(randomsource.nextInt(20) - 10, randomsource.nextInt(6) - 3, randomsource.nextInt(20) - 10);

			if (!entity.getWorld().isSkyVisible(hidePos) && entity.getPathfindingFavor(hidePos) < 0.0F)
				return Vec3d.ofBottomCenter(hidePos);
		}

		return null;
	}
}
