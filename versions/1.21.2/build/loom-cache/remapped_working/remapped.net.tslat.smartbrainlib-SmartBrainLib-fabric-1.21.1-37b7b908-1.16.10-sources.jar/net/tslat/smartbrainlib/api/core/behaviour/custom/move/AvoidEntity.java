package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.NoPenaltyTargeting;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtils;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Try to move away from certain entities when they get too close. <br>
 * Defaults:
 * <ul>
 *     <li>3 block minimum distance</li>
 *     <li>7 block maximum distance</li>
 *     <li>1x move speed modifier</li>
 * </ul>
 */
public class AvoidEntity<E extends PathAwareEntity> extends ExtendedBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(1).hasMemory(MemoryModuleType.VISIBLE_MOBS);

	protected Predicate<LivingEntity> avoidingPredicate = target -> false;
	protected float noCloserThanSqr = 9f;
	protected float stopAvoidingAfterSqr = 49f;
	protected float speedModifier = 1;

	private Path runPath = null;

	public AvoidEntity() {
		noTimeout();
	}

	/**
	 * Set the minimum distance the target entity should be allowed to come before the entity starts retreating.
	 * @param blocks The distance, in blocks
	 * @return this
	 */
	public AvoidEntity<E> noCloserThan(float blocks) {
		this.noCloserThanSqr = blocks * blocks;

		return this;
	}

	/**
	 * Set the maximum distance the target entity should be before the entity stops retreating.
	 * @param blocks The distance, in blocks
	 * @return this
	 */
	public AvoidEntity<E> stopCaringAfter(float blocks) {
		this.stopAvoidingAfterSqr = blocks * blocks;

		return this;
	}

	/**
	 * Sets the predicate for entities to avoid.
	 * @param predicate The predicate
	 * @return this
	 */
	public AvoidEntity<E> avoiding(Predicate<LivingEntity> predicate) {
		this.avoidingPredicate = predicate;

		return this;
	}

	/**
	 * Set the movespeed modifier for when the entity is running away.
	 * @param mod The speed multiplier modifier
	 * @return this
	 */
	public AvoidEntity<E> speedModifier(float mod) {
		this.speedModifier = mod;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean checkExtraStartConditions(ServerWorld level, E entity) {
		Optional<LivingEntity> target = BrainUtils.getMemory(entity, MemoryModuleType.VISIBLE_MOBS).findFirst(this.avoidingPredicate);

		if (target.isEmpty())
			return false;

		LivingEntity avoidingEntity = target.get();
		double distToTarget = avoidingEntity.squaredDistanceTo(entity);

		if (distToTarget > this.noCloserThanSqr)
			return false;

		Vec3d runPos = NoPenaltyTargeting.findFrom(entity, 16, 7, avoidingEntity.getPos());

		if (runPos == null || avoidingEntity.squaredDistanceTo(runPos.x, runPos.y, runPos.z) < distToTarget)
			return false;

		this.runPath = entity.getNavigation().findPathTo(runPos.x, runPos.y, runPos.z, 0);

		return this.runPath != null;
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		return !this.runPath.isFinished();
	}

	@Override
	protected void start(E entity) {
		entity.getNavigation().startMovingAlong(this.runPath, this.speedModifier);
	}

	@Override
	protected void stop(E entity) {
		this.runPath = null;

		entity.getNavigation().setSpeed(1);
	}
}
