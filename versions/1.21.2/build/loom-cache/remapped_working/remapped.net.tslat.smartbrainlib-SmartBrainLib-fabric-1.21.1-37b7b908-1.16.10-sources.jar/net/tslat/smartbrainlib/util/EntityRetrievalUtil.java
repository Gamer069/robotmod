package net.tslat.smartbrainlib.util;

import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.function.LazyIterationConsumer;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.entity.SectionedEntityCache;
import net.minecraft.world.entity.SimpleEntityLookup;
import net.tslat.smartbrainlib.SBLConstants;
import org.apache.commons.lang3.mutable.MutableDouble;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * A helper class for retrieving entities from a given world.
 * <p>
 * This removes a lot of the overhead of vanilla's type-checking, casting and redundant stream-collection.
 * <p>
 * Ultimately this leaves some casting up to the end-user, and streamlines the actual retrieval functions to their most optimised form.
 */
@SuppressWarnings({"unchecked", "unused"})
public final class EntityRetrievalUtil {
	/**
	 * Get the nearest entity from an existing list of entities.
	 *
	 * @param origin   The center-point of the distance comparison
	 * @param entities The existing list of entities
	 * @return         The closest entity to the origin point, or null if the input list was empty
	 * @param <T>      The entity type
	 */
	@Nullable
	public static <T extends Entity> T getNearest(Vec3d origin, List<T> entities) {
		if (entities.isEmpty())
			return null;

		double dist = Double.MAX_VALUE;
		T closest = null;

		for (T entity : entities) {
			double entityDist = entity.squaredDistanceTo(origin);

			if (entityDist < dist) {
				dist = entityDist;
				closest = entity;
			}
		}

		return closest;
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T> Optional<T> getNearestEntity(Entity origin, double radius) {
		return getNearestEntity(origin, radius, radius, radius);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T> Optional<T> getNearestEntity(Entity origin, double radiusX, double radiusY, double radiusZ) {
		return Optional.ofNullable((T)getNearestEntity(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), origin.getPos(), entity -> entity != origin));
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radius) {
		return getNearestEntity(level, origin, radius, radius, radius);
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ) {
		return getNearestEntity(level, Box.of(origin, radiusX, radiusY, radiusZ), origin);
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Box bounds, Vec3d origin) {
		return (Optional<T>)getNearestEntity(level, bounds, origin, Entity.class);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> getNearestEntity(Entity origin, double radius, Class<T> minimumClass) {
		return getNearestEntity(origin, radius, radius, radius, minimumClass);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> getNearestEntity(Entity origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass) {
		return getNearestEntity(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), origin.getPos(), minimumClass, entity -> entity != origin);
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radius, Class<T> minimumClass) {
		return getNearestEntity(level, origin, radius, radius, radius, minimumClass);
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass) {
		return getNearestEntity(level, Box.of(origin, radiusX, radiusY, radiusZ), origin, minimumClass);
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Box bounds, Vec3d origin, Class<T> minimumClass) {
		return getNearestEntity(level, bounds, origin, minimumClass, entity -> true);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> T getNearestEntity(Entity origin, double radius, Predicate<? extends Entity> predicate) {
		return getNearestEntity(origin, radius, radius, radius, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> T getNearestEntity(Entity origin, double radiusX, double radiusY, double radiusZ, Predicate<? extends Entity> predicate) {
		return getNearestEntity(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), origin.getPos(), ((Predicate<Entity>)entity -> entity != origin).and((Predicate<Entity>)predicate));
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radius, Predicate<Entity> predicate) {
		return getNearestEntity(level, origin, radius, radius, radius, predicate);
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Predicate<Entity> predicate) {
		return Optional.ofNullable(getNearestEntity(level, Box.of(origin, radiusX, radiusY, radiusZ), origin, predicate));
	}

	@Nullable
	public static <T extends Entity> T getNearestEntity(World level, Box bounds, Vec3d origin, Predicate<? extends Entity> predicate) {
		return (T)getNearestEntity(level, bounds, origin, Entity.class, (Predicate<Entity>)predicate).orElse(null);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> getNearestEntity(Entity origin, double radius, Class<T> minimumClass, Predicate<T> predicate) {
		return getNearestEntity(origin, radius, radius, radius, minimumClass, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> getNearestEntity(Entity origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, Predicate<T> predicate) {
		return getNearestEntity(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), origin.getPos(), minimumClass, ((Predicate<T>)entity -> entity != origin).and(predicate));
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radius, Class<T> minimumClass, Predicate<T> predicate) {
		return getNearestEntity(level, Box.of(origin, radius, radius, radius), origin, minimumClass, predicate);
	}

	public static <T extends Entity> Optional<T> getNearestEntity(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, Predicate<T> predicate) {
		return getNearestEntity(level, Box.of(origin, radiusX, radiusY, radiusZ), origin, minimumClass, predicate);
	}

	/**
	 * Retrieve the entity found within the bounds that is closest to the origin point
	 * <p>
	 * Note that the output is blind-cast to your intended output type for ease of
	 * use. Make sure you check {@code instanceof} in your predicate if you intend
	 * to use any subclass of Entity
	 *
	 * @param level      The level to search in
	 * @param bounds     The region to search for entities in
	 * @param origin     The center-point of the search
	 * @param predicate  The predicate to filter entities by
	 * @return           The closest entity found that meets the given criteria, or null if none found
	 * @param <T>        The class in which all checked entities should be or extend. More specific typings are more efficient
	 */
	public static <T extends Entity> Optional<T> getNearestEntity(World level, Box bounds, Vec3d origin, Class<T> minimumClass, Predicate<T> predicate) {
		final MutableDouble dist = new MutableDouble(Double.MAX_VALUE);
		final MutableObject<T> closest = new MutableObject<>(null);
		final TypeFilter<Entity, T> typeTest = makeLazyTypeTest(minimumClass);

		level.getEntityLookup().forEachIntersects(typeTest, bounds, entity -> {
			if (predicate.test(entity)) {
				double entityDist = entity.squaredDistanceTo(origin);

				if (entityDist < dist.doubleValue()) {
					dist.setValue(entityDist);
					closest.setValue(entity);
				}
			}

			return LazyIterationConsumer.NextIteration.CONTINUE;
		});

		return Optional.ofNullable(closest.getValue());
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends PlayerEntity> T getNearestPlayer(Entity origin, double radius) {
		return getNearestPlayer(origin, radius, radius, radius);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends PlayerEntity> T getNearestPlayer(Entity origin, double radiusX, double radiusY, double radiusZ) {
		return (T)getNearestPlayer(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), origin.getPos(), entity -> entity != origin);
	}

	public static <T extends PlayerEntity> T getNearestPlayer(World level, Vec3d origin, double radius) {
		return getNearestPlayer(level, origin, radius, radius, radius);
	}

	public static <T extends PlayerEntity> T getNearestPlayer(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ) {
		return getNearestPlayer(level, Box.of(origin, radiusX, radiusY, radiusZ), origin);
	}

	public static <T extends PlayerEntity> T getNearestPlayer(World level, Box area, Vec3d origin) {
		return (T)getNearestPlayer(level, area, origin, pl -> true);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static PlayerEntity getNearestPlayer(Entity origin, double radius, Predicate<PlayerEntity> predicate) {
		return getNearestPlayer(origin, radius, radius, radius, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static PlayerEntity getNearestPlayer(Entity origin, double radiusX, double radiusY, double radiusZ, Predicate<PlayerEntity> predicate) {
		return getNearestPlayer(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), origin.getPos(), ((Predicate<PlayerEntity>)entity -> entity != origin).and(predicate));
	}

	public static <T extends PlayerEntity> T getNearestPlayer(World level, Vec3d origin, double radius, Predicate<PlayerEntity> predicate) {
		return getNearestPlayer(level, origin, radius, radius, radius, predicate);
	}

	public static <T extends PlayerEntity> T getNearestPlayer(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Predicate<PlayerEntity> predicate) {
		return (T)getNearestPlayer(level, Box.of(origin, radiusX, radiusY, radiusZ), origin, predicate);
	}

	/**
	 * Get all players within a given region that meet a given criteria.
	 * <p>
	 * This is an implicitly superior alternative to {@link #getEntities} when only looking for players, as this
	 * only searches the level's players, which is always a significantly smaller pool of targets to search from.
	 * <p>
	 * This should be used in all circumstances where you are only looking for players
	 *
	 * @param level      The level in which to search
	 * @param bounds     The region in which to find players
	 * @param predicate  The criteria to meet for a player to be included in the returned list
	 * @return           A list of all players that are within the given region that meet the criteria in the predicate
	 */
	@Nullable
	public static PlayerEntity getNearestPlayer(World level, Box bounds, Vec3d origin, Predicate<PlayerEntity> predicate) {
		double dist = Double.MAX_VALUE;
		PlayerEntity closest = null;

		for (PlayerEntity player : level.getPlayers()) {
			if (bounds.contains(player.getPos()) && predicate.test(player)) {
				double playerDist = player.squaredDistanceTo(origin);

				if (playerDist < dist) {
					dist = playerDist;
					closest = player;
				}
			}
		}

		return closest;
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static List<PlayerEntity> getPlayers(Entity origin, double radius) {
		return getPlayers(origin, radius, radius, radius);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static List<PlayerEntity> getPlayers(Entity origin, double radiusX, double radiusY, double radiusZ) {
		return getPlayers(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), entity -> entity != origin);
	}

	public static <T extends PlayerEntity> List<T> getPlayers(World level, Vec3d origin, double radius) {
		return getPlayers(level, origin, radius, radius, radius);
	}

	public static <T extends PlayerEntity> List<T> getPlayers(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ) {
		return (List<T>)getPlayers(level, Box.of(origin, radiusX, radiusY, radiusZ));
	}

	public static <T extends PlayerEntity> List<T> getPlayers(World level, Vec3d from, Vec3d to) {
		return (List<T>)getPlayers(level, new Box(from, to));
	}

	public static List<PlayerEntity> getPlayers(World level, Box area) {
		return getPlayers(level, area, pl -> true);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static List<PlayerEntity> getPlayers(Entity origin, double radius, Predicate<PlayerEntity> predicate) {
		return getPlayers(origin, radius, radius, radius, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static List<PlayerEntity> getPlayers(Entity origin, double radiusX, double radiusY, double radiusZ, Predicate<PlayerEntity> predicate) {
		return getPlayers(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), ((Predicate<PlayerEntity>)entity -> entity != origin).and(predicate));
	}

	public static <T extends PlayerEntity> List<T> getPlayers(World level, Vec3d origin, double radius, Predicate<PlayerEntity> predicate) {
		return getPlayers(level, origin, radius, radius, radius, predicate);
	}

	public static <T extends PlayerEntity> List<T> getPlayers(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Predicate<PlayerEntity> predicate) {
		return (List<T>)getPlayers(level, Box.of(origin, radiusX, radiusY, radiusZ), predicate);
	}

	public static <T extends PlayerEntity> List<T> getPlayers(World level, Vec3d from, Vec3d to, Predicate<PlayerEntity> predicate) {
		return (List<T>)getPlayers(level, new Box(from, to), predicate);
	}

	/**
	 * Get all players within a given region that meet a given criteria.
	 * <p>
	 * This is an implicitly superior alternative to {@link #getEntities} when only looking for players, as this
	 * only searches the level's players, which is always a significantly smaller pool of targets to search from.
	 * <br>
	 * This should be used in all circumstances where you are only looking for players
	 *
	 * @param level      The level in which to search
	 * @param bounds     The region in which to find players
	 * @param predicate  The criteria to meet for a player to be included in the returned list
	 * @return           A list of all players that are within the given region that meet the criteria in the predicate
	 */
	public static List<PlayerEntity> getPlayers(World level, Box bounds, Predicate<PlayerEntity> predicate) {
		List<PlayerEntity> players = new ObjectArrayList<>();

		for (PlayerEntity player : level.getPlayers()) {
			if (bounds.contains(player.getPos()) && predicate.test(player))
				players.add(player);
		}

		return players;
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T> List<T> getEntities(Entity origin, double radius) {
		return getEntities(origin, radius, radius, radius);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T> List<T> getEntities(Entity origin, double radiusX, double radiusY, double radiusZ) {
		return (List<T>)getEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), entity -> entity != origin);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radius) {
		return getEntities(level, Box.of(origin, radius, radius, radius));
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ) {
		return getEntities(level, Box.of(origin, radiusX, radiusY, radiusZ));
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d from, Vec3d to) {
		return getEntities(level, new Box(from, to));
	}

	public static <T extends Entity> List<T> getEntities(World level, Box area) {
		return (List<T>)getEntities(level, area, Entity.class);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> getEntities(Entity origin, double radius, Class<T> minimumClass) {
		return getEntities(origin, radius, radius, radius, minimumClass);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> getEntities(Entity origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass) {
		return getEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), minimumClass, entity -> entity != origin);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radius, Class<T> minimumClass) {
		return getEntities(level, Box.of(origin, radius, radius, radius), minimumClass);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass) {
		return getEntities(level, Box.of(origin, radiusX, radiusY, radiusZ), minimumClass);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d from, Vec3d to, Class<T> minimumClass) {
		return getEntities(level, new Box(from, to), minimumClass);
	}

	public static <T extends Entity> List<T> getEntities(World level, Box bounds, Class<T> minimumClass) {
		return getEntities(level, bounds, minimumClass, entity -> true);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T> List<T> getEntities(Entity origin, double radius, Predicate<? extends Entity> predicate) {
		return getEntities(origin, radius, radius, radius, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T> List<T> getEntities(Entity origin, double radiusX, double radiusY, double radiusZ, Predicate<? extends Entity> predicate) {
		return (List<T>)getEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), ((Predicate<Entity>)entity -> entity != origin).and((Predicate<Entity>)predicate));
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radius, Predicate<Entity> predicate) {
		return getEntities(level, Box.of(origin, radius, radius, radius), predicate);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Predicate<Entity> predicate) {
		return getEntities(level, Box.of(origin, radiusX, radiusY, radiusZ), predicate);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d from, Vec3d to, Predicate<Entity> predicate) {
		return getEntities(level, new Box(from, to), predicate);
	}

	public static <T extends Entity> List<T> getEntities(World level, Box area, Predicate<? extends Entity> predicate) {
		return (List<T>)getEntities(level, area, Entity.class, (Predicate<Entity>)predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> getEntities(Entity origin, double radius, Class<T> minimumClass, Predicate<T> predicate) {
		return getEntities(origin, radius, radius, radius, minimumClass, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> getEntities(Entity origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, Predicate<T> predicate) {
		return getEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), minimumClass, ((Predicate<T>)entity -> entity != origin).and(predicate));
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radius, Class<T> minimumClass, Predicate<T> predicate) {
		return getEntities(level, Box.of(origin, radius, radius, radius), minimumClass, predicate);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, Predicate<T> predicate) {
		return getEntities(level, Box.of(origin, radiusX, radiusY, radiusZ), minimumClass, predicate);
	}

	public static <T extends Entity> List<T> getEntities(World level, Vec3d from, Vec3d to, Class<T> minimumClass, Predicate<T> predicate) {
		return getEntities(level, new Box(from, to), minimumClass, predicate);
	}

	/**
	 * Get all entities within a given region that meet a given criteria.
	 *
	 * @param level         The level to search in
	 * @param bounds        The region to search for entities in
	 * @param minimumClass  The minimum common class (E.G. LivingEntity) that all entities found must be
	 * @param predicate     The predicate determining a valid match
	 * @return              A list of all entities present in the given area that are of at least the minimumClass type, meeting the predicate conditions
	 * @param <T>           The class in which all checked entities should be or extend. More specific typings are more efficient
	 */
	public static <T extends Entity> List<T> getEntities(World level, Box bounds, Class<T> minimumClass, Predicate<T> predicate) {
		final List<T> foundEntities = new ObjectArrayList<>();
		final TypeFilter<Entity, T> typeTest = makeLazyTypeTest(minimumClass);

		level.getEntityLookup().forEachIntersects(typeTest, bounds, entity -> {
			if (predicate.test(entity))
				foundEntities.add(entity);

			return LazyIterationConsumer.NextIteration.CONTINUE;
		});

		Pair<Collection<? extends Entity>, Function<Entity, ? extends Entity>> partEntities = SBLConstants.SBL_LOADER.getPartEntities(level);

		for (Entity part : partEntities.getFirst()) {
			T entity = typeTest.downcast(partEntities.getSecond().apply(part));

			if (entity != null && part.getBoundingBox().intersects(bounds) && predicate.test(entity))
				foundEntities.add(entity);
		}

		return foundEntities;
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends PlayerEntity> Optional<T> findPlayer(Entity origin, double radius, Predicate<PlayerEntity> predicate) {
		return findPlayer(origin, radius, radius, radius, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends PlayerEntity> Optional<T> findPlayer(Entity origin, double radiusX, double radiusY, double radiusZ, Predicate<PlayerEntity> predicate) {
		return findPlayer(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), ((Predicate<PlayerEntity>)entity -> entity != origin).and(predicate));
	}

	public static <T extends PlayerEntity> Optional<T> findPlayer(World level, Vec3d origin, double radius, Predicate<PlayerEntity> predicate) {
		return findPlayer(level, Box.of(origin, radius, radius, radius), predicate);
	}

	public static <T extends PlayerEntity> Optional<T> findPlayer(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Predicate<PlayerEntity> predicate) {
		return findPlayer(level, Box.of(origin, radiusX, radiusY, radiusZ), predicate);
	}

	public static <T extends PlayerEntity> Optional<T> findPlayer(World level, Vec3d from, Vec3d to, Predicate<PlayerEntity> predicate) {
		return findPlayer(level, new Box(from, to), predicate);
	}

	/**
	 * Find a single player within a given region that meets a given criteria.
	 * <p>
	 * This is a short-circuiting operation that ends immediately upon finding a matching target, offering optimal efficiency when searching for a specific player.
	 *
	 * @param level      The level to search in
	 * @param bounds     The region to search for players in
	 * @param predicate  The predicate determining a valid match
	 * @return           The first player that meets the predicate conditions, or an empty {@link Optional} if none found
	 */
	public static <T extends PlayerEntity> Optional<T> findPlayer(World level, Box bounds, Predicate<PlayerEntity> predicate) {
		for (PlayerEntity player : level.getPlayers()) {
			if (bounds.contains(player.getPos()) && predicate.test(player))
				return (Optional<T>)Optional.of(player);
		}

		return Optional.empty();
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> findEntity(Entity origin, double radius, Predicate<Entity> predicate) {
		return findEntity(origin, radius, radius, radius, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> findEntity(Entity origin, double radiusX, double radiusY, double radiusZ, Predicate<Entity> predicate) {
		return findEntity(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), ((Predicate<Entity>)entity -> entity != origin).and(predicate));
	}

	public static <T extends Entity> Optional<T> findEntity(World level, Vec3d origin, double radius, Predicate<Entity> predicate) {
		return findEntity(level, Box.of(origin, radius, radius, radius), predicate);
	}

	public static <T extends Entity> Optional<T> findEntity(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Predicate<Entity> predicate) {
		return findEntity(level, Box.of(origin, radiusX, radiusY, radiusZ), predicate);
	}

	public static <T extends Entity> Optional<T> findEntity(World level, Vec3d from, Vec3d to, Predicate<Entity> predicate) {
		return findEntity(level, new Box(from, to), predicate);
	}

	public static <T extends Entity> Optional<T> findEntity(World level, Box bounds, Predicate<Entity> predicate) {
		return (Optional<T>)findEntity(level, bounds, Entity.class, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> findEntity(Entity origin, double radius, Class<T> minimumClass, Predicate<T> predicate) {
		return findEntity(origin, radius, radius, radius, minimumClass, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> Optional<T> findEntity(Entity origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, Predicate<T> predicate) {
		return findEntity(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), minimumClass, ((Predicate<T>)entity -> entity != origin).and(predicate));
	}

	public static <T extends Entity> Optional<T> findEntity(World level, Vec3d origin, double radius, Class<T> minimumClass, Predicate<T> predicate) {
		return findEntity(level, Box.of(origin, radius, radius, radius), minimumClass, predicate);
	}

	public static <T extends Entity> Optional<T> findEntity(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, Predicate<T> predicate) {
		return findEntity(level, Box.of(origin, radiusX, radiusY, radiusZ), minimumClass, predicate);
	}

	public static <T extends Entity> Optional<T> findEntity(World level, Vec3d from, Vec3d to, Class<T> minimumClass, Predicate<T> predicate) {
		return findEntity(level, new Box(from, to), minimumClass, predicate);
	}

	/**
	 * Find a single entity within a given region that meet a given criteria.
	 * <p>
	 * This is a short-circuiting operation that ends immediately upon finding a matching target, offering optimal efficiency when searching for a specific entity.
	 * <p>
	 * If using one of the override methods that do not take a <i>minimumClass</i> argument, it's up to the user to ensure you
	 * type-check the entity instance in the predicate to prevent class exceptions from the returned object
	 *
	 * @param level         The level to search in
	 * @param bounds        The region to search for entities in
	 * @param minimumClass  The minimum common class (E.G. LivingEntity) that all entities found must be
	 * @param predicate     The predicate determining a valid match
	 * @return              The first entity that is of at least the minimumClass type, meeting the predicate conditions, or an empty {@link Optional} if none found
	 * @param <T>           The class in which all checked entities should be or extend. More specific typings are more efficient
	 */
	public static <T extends Entity> Optional<T> findEntity(World level, Box bounds, Class<T> minimumClass, Predicate<T> predicate) {
		final AtomicReference<T> foundEntity = new AtomicReference<>(null);
		final TypeFilter<Entity, T> typeTest = makeLazyTypeTest(minimumClass);

		level.getEntityLookup().forEachIntersects(typeTest, bounds, entity -> {
			if (predicate.test(entity)) {
				foundEntity.set(entity);

				return LazyIterationConsumer.NextIteration.ABORT;
			}

			return LazyIterationConsumer.NextIteration.CONTINUE;
		});

		if (foundEntity.get() == null) {
			Pair<Collection<? extends Entity>, Function<Entity, ? extends Entity>> partEntities = SBLConstants.SBL_LOADER.getPartEntities(level);

			for (Entity part : partEntities.getFirst()) {
				T entity = typeTest.downcast(partEntities.getSecond().apply(part));

				if (entity != null && part.getBoundingBox().intersects(bounds) && predicate.test(entity)) {
					foundEntity.set(entity);

					break;
				}
			}
		}

		return Optional.ofNullable(foundEntity.get());
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> findEntities(Entity origin, double radius, int max, Predicate<Entity> predicate) {
		return findEntities(origin, radius, radius, radius, max, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> findEntities(Entity origin, double radiusX, double radiusY, double radiusZ, int max, Predicate<Entity> predicate) {
		return (List<T>)findEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), Entity.class, max, ((Predicate<Entity>)entity -> entity != origin).and(predicate));
	}

	public static <T extends Entity> List<T> findEntities(World level, Vec3d origin, double radius, int max, Predicate<Entity> predicate) {
		return findEntities(level, origin, radius, radius, radius, max, predicate);
	}

	public static <T extends Entity> List<T> findEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, int max, Predicate<Entity> predicate) {
		return (List<T>)findEntities(level, Box.of(origin, radiusX, radiusY, radiusZ), Entity.class, max, predicate);
	}

	public static <T extends Entity> List<T> findEntities(World level, Vec3d from, Vec3d to, int max, Predicate<Entity> predicate) {
		return (List<T>)findEntities(level, new Box(from, to), Entity.class, max, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> findEntities(Entity origin, double radius, Class<T> minimumClass, int max, Predicate<? super T> predicate) {
		return findEntities(origin, radius, radius, radius, minimumClass, max, predicate);
	}

	/**
	 * NOTE: The origin entity will be automatically excluded from the search and will not be passed to the predicate
	 */
	public static <T extends Entity> List<T> findEntities(Entity origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, int max, Predicate<? super T> predicate) {
		return findEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), minimumClass, max, ((Predicate<T>)entity -> entity != origin).and(predicate));
	}

	public static <T extends Entity> List<T> findEntities(World level, Vec3d origin, double radius, Class<T> minimumClass, int max, Predicate<? super T> predicate) {
		return findEntities(level, Box.of(origin, radius, radius, radius), minimumClass, max, predicate);
	}

	public static <T extends Entity> List<T> findEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass, int max, Predicate<? super T> predicate) {
		return findEntities(level, Box.of(origin, radiusX, radiusY, radiusZ), minimumClass, max, predicate);
	}

	public static <T extends Entity> List<T> findEntities(World level, Vec3d from, Vec3d to, Class<T> minimumClass, int max, Predicate<? super T> predicate) {
		return findEntities(level, new Box(from, to), minimumClass, max, predicate);
	}

	/**
	 * Find up to a predefined number of entity instances in the given region of the given minimum common class type, predicated by the provided predicate.
	 * <p>
	 * This is a short-circuiting operation that ends immediately upon finding enough matching targets, offering optimal efficiency when searching for a specific entities.
	 * <p>
	 * If using one of the override methods that do not take a <i>minimumClass</i> argument, it's up to the user to ensure you
	 * type-check the entity instance in the predicate to prevent class exceptions from the returned object
	 *
	 * @param level         The level to search in
	 * @param bounds        The region to search for entities in
	 * @param minimumClass  The minimum common class (E.G. LivingEntity) that all entities found must be
	 * @param max           The maximum amount of entities to search for
	 * @param predicate     The predicate determining a valid match
	 * @return              A list of all entities (up to max amount) that are of at least the minimumClass type, meeting the predicate conditions
	 * @param <T>           The class in which all checked entities should be or extend. More specific typings are more efficient
	 */
	public static <T extends Entity> List<T> findEntities(World level, Box bounds, Class<T> minimumClass, int max, Predicate<? super T> predicate) {
		final List<T> foundEntities = new ObjectArrayList<>(max);
		final TypeFilter<Entity, T> typeTest = makeLazyTypeTest(minimumClass);

		level.getEntityLookup().forEachIntersects(typeTest, bounds, entity -> {
			if (predicate.test(entity)) {
				foundEntities.add(entity);

				if (foundEntities.size() >= max)
					return LazyIterationConsumer.NextIteration.ABORT;
			}

			return LazyIterationConsumer.NextIteration.CONTINUE;
		});

		if (foundEntities.size() < max) {
			Pair<Collection<? extends Entity>, Function<Entity, ? extends Entity>> partEntities = SBLConstants.SBL_LOADER.getPartEntities(level);

			for (Entity part : partEntities.getFirst()) {
				T entity = typeTest.downcast(partEntities.getSecond().apply(part));

				if (entity != null && part.getBoundingBox().intersects(bounds) && predicate.test(entity)) {
					foundEntities.add(entity);

					if (foundEntities.size() >= max)
						break;
				}
			}
		}

		return foundEntities;
	}

	/**
	 * NOTE: The returned stream may include the origin entity in its contents
	 */
	public static Stream<Entity> streamEntities(Entity origin, double radius) {
		return streamEntities(origin, radius, radius, radius);
	}

	/**
	 * NOTE: The returned stream may include the origin entity in its contents
	 */
	public static Stream<Entity> streamEntities(Entity origin, double radiusX, double radiusY, double radiusZ) {
		return streamEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), Entity.class);
	}

	public static Stream<Entity> streamEntities(World level, Vec3d origin, double radius) {
		return streamEntities(level, origin, radius, radius, radius);
	}

	public static Stream<Entity> streamEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ) {
		return streamEntities(level, Box.of(origin, radiusX, radiusY, radiusZ), Entity.class);
	}

	public static Stream<Entity> streamEntities(World level, Vec3d fromPos, Vec3d toPos) {
		return streamEntities(level, new Box(fromPos, toPos), Entity.class);
	}

	/**
	 * NOTE: The returned stream may include the origin entity in its contents
	 */
	public static <T extends Entity> Stream<T> streamEntities(Entity origin, double radius, Class<T> minimumClass) {
		return streamEntities(origin, radius, radius, radius, minimumClass);
	}

	/**
	 * NOTE: The returned stream may include the origin entity in its contents
	 */
	public static <T extends Entity> Stream<T> streamEntities(Entity origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass) {
		return streamEntities(origin.getWorld(), origin.getBoundingBox().expand(radiusX, radiusY, radiusZ), minimumClass);
	}

	public static <T extends Entity> Stream<T> streamEntities(World level, Vec3d origin, double radius, Class<T> minimumClass) {
		return streamEntities(level, origin, radius, radius, radius, minimumClass);
	}

	public static <T extends Entity> Stream<T> streamEntities(World level, Vec3d origin, double radiusX, double radiusY, double radiusZ, Class<T> minimumClass) {
		return streamEntities(level, Box.of(origin, radiusX, radiusY, radiusZ), minimumClass);
	}

	public static <T extends Entity> Stream<T> streamEntities(World level, Vec3d fromPos, Vec3d toPos, Class<T> minimumClass) {
		return streamEntities(level, new Box(fromPos, toPos), minimumClass);
	}

	/**
	 * Create a stream of all entities in the given area for the given minimum common class type.
	 * <p>
	 * This is usually less efficient than the standard List lookups, however you may want to use this in a few circumstances:
	 * <ol>
	 *     <li>You specifically need/want a stream that can properly short-circuit for better performance
	 *     <li>You are looking for a number of entities that meet some criteria but may quit searching before checking all of them
	 * </ol>
	 *
	 * @param level         The level to search in
	 * @param bounds        The region to search for entities in
	 * @param minimumClass  The minimum common class (E.G. LivingEntity) that all entities found must be
	 * @return              A stream of all entities in the bounds of the minimum class type
	 * @param <T>           The class in which all returned entities should be or extend. More specific typings are more efficient
	 */
	public static <T extends Entity> Stream<T> streamEntities(World level, Box bounds, Class<T> minimumClass) {
		level.method_16107().method_39278("getEntities");

		if (!(level.getEntityLookup() instanceof SimpleEntityLookup<Entity> entities))
			return (minimumClass == Entity.class ? (List)getEntities(level, bounds, entity -> true) : getEntities(level, bounds, minimumClass, entity -> true)).stream();

		final SectionedEntityCache<Entity> entitySectionStorage = entities.cache;
		final TypeFilter<Entity, T> clazzLookup = makeLazyTypeTest(minimumClass);
		final int minSectionX = ChunkSectionPos.getSectionCoord(bounds.minX - 2);
		final int minSectionY = ChunkSectionPos.getSectionCoord(bounds.minY - 4);
		final int minSectionZ = ChunkSectionPos.getSectionCoord(bounds.minZ - 2);
		final int maxSectionX = ChunkSectionPos.getSectionCoord(bounds.maxX + 2);
		final int maxSectionY = ChunkSectionPos.getSectionCoord(bounds.maxY);
		final int maxSectionZ = ChunkSectionPos.getSectionCoord(bounds.maxZ + 2);
		final Pair<Collection<? extends Entity>, Function<Entity, ? extends Entity>> partEntities = SBLConstants.SBL_LOADER.getPartEntities(level);
		final Stream<T> stream = IntStream.rangeClosed(minSectionX, maxSectionX)
				.mapToObj(sectionX -> entitySectionStorage.trackedPositions.subSet(ChunkSectionPos.asLong(sectionX, 0, 0), ChunkSectionPos.asLong(sectionX, -1, -1)).iterator())
				.<Long>mapMulti((iterator, consumer) -> consumer.accept(iterator.nextLong()))
				.filter(sectionId -> {
					int sectionYPos = class_4076.method_18689(sectionId);

					if (sectionYPos < minSectionY || sectionYPos > maxSectionY)
						return false;

					int sectionZPos = class_4076.method_18690(sectionId);

                    return sectionZPos >= minSectionZ && sectionZPos <= maxSectionZ;
                })
				.map(entitySectionStorage::findTrackingSection)
				.filter(section -> section != null && !section.method_31761() && section.method_31768().method_31885())
				.map(section -> section.field_27248.method_15216(clazzLookup.method_31794()))
				.filter(collection -> !collection.isEmpty())
				.<Entity>mapMulti(Iterable::forEach)
				.map(clazzLookup::downcast)
				.filter(entity -> entity != null && entity.method_5829().method_994(bounds));

		return partEntities.getFirst().isEmpty() ?
				stream :
				Stream.concat(
						stream,
						partEntities.getFirst().stream()
								.map(entity -> Pair.of(entity, clazzLookup.downcast(partEntities.getSecond().apply(entity))))
								.filter(entity -> entity.getFirst().getBoundingBox().intersects(bounds))
								.map(Pair::getSecond));
	}

	/**
	 * Internal method for wrapping the {@link TypeFilter} system to account for root {@link Entity} types,
	 * which don't need wasteful instance checks and casting for every instance
	 */
	@ApiStatus.Internal
	private static <T extends Entity> TypeFilter<Entity, T> makeLazyTypeTest(Class<T> forClass) {
		if (forClass != Entity.class)
			return TypeFilter.instanceOf(forClass);

		return (TypeFilter<Entity, T>)new TypeFilter<Entity, Entity>() {
			@Nullable
			@Override
			public Entity tryCast(Entity entity) {
				return entity;
			}

			@Override
			public Class<? extends Entity> getBaseClass() {
				return Entity.class;
			}
		};
	}
}
