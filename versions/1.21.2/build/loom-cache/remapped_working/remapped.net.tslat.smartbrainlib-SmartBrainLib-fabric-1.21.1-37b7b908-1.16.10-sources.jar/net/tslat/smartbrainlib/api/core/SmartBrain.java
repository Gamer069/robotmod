package net.tslat.smartbrainlib.api.core;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Activity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.Memory;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.Schedule;
import net.minecraft.entity.ai.brain.sensor.Sensor;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.ai.brain.task.CompositeTask;
import net.minecraft.entity.ai.brain.task.MultiTickTask;
import net.minecraft.entity.ai.brain.task.Task;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.SmartBrainOwner;
import net.tslat.smartbrainlib.api.core.behaviour.GroupBehaviour;
import net.tslat.smartbrainlib.api.core.schedule.SmartBrainSchedule;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.object.BrainBehaviourConsumer;
import net.tslat.smartbrainlib.object.BrainBehaviourPredicate;
import net.tslat.smartbrainlib.util.BrainUtils;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * Supercedes vanilla's {@link Brain}. One of the core components of the SBL
 * library. <br>
 * Any entity that returns a {@link SmartBrainProvider} from
 * {@link LivingEntity#createBrainProfile()} will have one of these.
 * 
 * @param <E> The entity
 */
public class SmartBrain<E extends LivingEntity & SmartBrainOwner<E>> extends Brain<E> {
	protected final List<MemoryModuleType<?>> expirableMemories = new ObjectArrayList<>();
	protected final List<ActivityBehaviours<E>> behaviours = new ObjectArrayList<>();
	protected final List<Pair<SensorType<ExtendedSensor<? super E>>, ExtendedSensor<? super E>>> sensors = new ObjectArrayList<>();
	protected SmartBrainSchedule schedule = null;

	protected boolean sortBehaviours = false;

	public SmartBrain(List<MemoryModuleType<?>> memories, List<? extends ExtendedSensor<E>> sensors, @Nullable List<BrainActivityGroup<E>> taskList) {
		super(memories, ImmutableList.of(), ImmutableList.of(), SmartBrain::emptyBrainCodec);

		for (ExtendedSensor<E> sensor : sensors) {
			this.sensors.add(Pair.of((SensorType)sensor.type(), sensor));
		}

		if (taskList != null) {
			for (BrainActivityGroup<E> group : taskList) {
				addActivity(group);
			}
		}
	}

	@Override
	public void tick(ServerWorld level, E entity) {
		entity.getWorld().method_16107().method_15396("SmartBrain");

		if (this.sortBehaviours)
			this.behaviours.sort(Comparator.comparingInt(ActivityBehaviours::priority));

		tickMemories();
		tickSensors(level, entity);
		checkForNewBehaviours(level, entity);
		tickRunningBehaviours(level, entity);
		findAndSetActiveActivity(entity);

		entity.getWorld().method_16107().method_15407();

		if (entity instanceof MobEntity mob)
			mob.setAttacking(BrainUtils.hasMemory(mob, MemoryModuleType.ATTACK_TARGET));
	}

	protected void findAndSetActiveActivity(E entity) {
		Activity nextActivity = getFirstValidActivity(entity.getActivityPriorities());

		if (nextActivity != null && entity.getScheduleIgnoringActivities().contains(nextActivity)) {
			resetPossibleActivities(nextActivity);

			return;
		}

		if (this.schedule != null) {
			Activity scheduledActivity = this.schedule.tick(entity);

			if (scheduledActivity != null && canDoActivity(scheduledActivity)) {
				if (!hasActivity(scheduledActivity))
					resetPossibleActivities(scheduledActivity);

				return;
			}
		}

		if (nextActivity != null)
			resetPossibleActivities(nextActivity);
	}

	@Nullable
	protected Activity getFirstValidActivity(List<Activity> activities) {
		for (Activity activity : activities) {
			if (canDoActivity(activity))
				return activity;
		}

		return null;
	}

	protected void tickSensors(ServerWorld level, E entity) {
		for (Pair<SensorType<ExtendedSensor<? super E>>, ExtendedSensor<? super E>> sensor : this.sensors) {
			sensor.getSecond().tick(level, entity);
		}
	}

	protected void checkForNewBehaviours(ServerWorld level, E entity) {
		long gameTime = level.getTime();

		for (ActivityBehaviours<E> behaviourGroup : this.behaviours) {
			for (Pair<Activity, List<Task<? super E>>> pair : behaviourGroup.behaviours) {
				if (getPossibleActivities().contains(pair.getFirst())) {
					for (Task<? super E> behaviour : pair.getSecond()) {
						if (behaviour.getStatus() == MultiTickTask.Status.STOPPED)
							behaviour.tryStarting(level, entity, gameTime);
					}
				}
			}
		}
	}

	protected void tickRunningBehaviours(ServerWorld level, E entity) {
		long gameTime = level.getTime();

		for (ActivityBehaviours<E> behaviourGroup : this.behaviours) {
			for (Pair<Activity, List<Task<? super E>>> pair : behaviourGroup.behaviours) {
				for (Task<? super E> behaviour : pair.getSecond()) {
					if (behaviour.getStatus() == MultiTickTask.Status.RUNNING)
						behaviour.tick(level, entity, gameTime);
				}
			}
		}
	}

	@Override
	public void tickMemories() {
		Iterator<MemoryModuleType<?>> expirable = this.expirableMemories.iterator();

		while (expirable.hasNext()) {
			MemoryModuleType<?> memoryType = expirable.next();
			Optional<? extends Memory<?>> memory = memories.get(memoryType);

			if (memory.isEmpty()) {
				expirable.remove();
			}
			else {
				Memory<?> value = memory.get();

				if (!value.isTimed()) {
					expirable.remove();
				}
				else if (value.isExpired()) {
					expirable.remove();
					forget(memoryType);
				}
				else {
					value.tick();
				}
			}
		}
	}

	@Override
	public void stopAllTasks(ServerWorld level, E entity) {
		long gameTime = level.getTime();

		for (ActivityBehaviours<E> behaviourGroup : this.behaviours) {
			for (Pair<Activity, List<Task<? super E>>> pair : behaviourGroup.behaviours) {
				for (Task<? super E> behaviour : pair.getSecond()) {
					if (behaviour.getStatus() == MultiTickTask.Status.RUNNING)
						behaviour.stop(level, entity, gameTime);
				}
			}
		}
	}

	@Override
	public <U> Optional<U> getOptionalRegisteredMemory(MemoryModuleType<U> type) {
		return (Optional<U>) this.memories.computeIfAbsent(type, key -> Optional.empty()).map(Memory::getValue);
	}

	@Override
	public <U> void setMemory(MemoryModuleType<U> memoryType, Optional<? extends Memory<?>> memory) {
		if (memory.isPresent() && memory.get().getValue()instanceof Collection<?> collection && collection.isEmpty())
			memory = Optional.empty();

		this.memories.put(memoryType, memory);

		if (memory.isPresent() && memory.get().isTimed() && !this.expirableMemories.contains(memoryType))
			this.expirableMemories.add(memoryType);
	}

	@Override
	public <U> boolean hasMemoryModuleWithValue(MemoryModuleType<U> memoryType, U memory) {
		Optional<U> value = getOptionalRegisteredMemory(memoryType);

		return value.isPresent() && value.get().equals(memory);
	}

	protected static <E extends LivingEntity & SmartBrainOwner<E>> Codec<Brain<E>> emptyBrainCodec() {
		MutableObject<Codec<Brain<E>>> brainCodec = new MutableObject<>();

		brainCodec.setValue(Codec.unit(() -> new Brain<>(ImmutableList.of(), ImmutableList.of(), ImmutableList.of(), brainCodec::getValue)));

		return brainCodec.getValue();
	}

	protected static <E extends LivingEntity & SmartBrainOwner<E>> List<? extends SensorType<? extends Sensor<? super E>>> convertSensorsToTypes(List<? extends ExtendedSensor<E>> sensors) {
		List<SensorType<? extends Sensor<? super E>>> types = new ObjectArrayList<>(sensors.size());

		for (ExtendedSensor<?> sensor : sensors) {
			types.add((SensorType)sensor.type());
		}

		return types;
	}

	@Override
	public Brain<E> copy() {
		SmartBrain<E> brain = new SmartBrain<>(this.memories.keySet().stream().toList(), this.sensors.stream().map(pair -> (ExtendedSensor<E>) pair.getSecond()).toList(), null);

		for (Map.Entry<MemoryModuleType<?>, Optional<? extends Memory<?>>> entry : this.memories.entrySet()) {
			MemoryModuleType<?> memoryType = entry.getKey();

			if (entry.getValue().isPresent())
				brain.memories.put(memoryType, entry.getValue());
		}

		return brain;
	}

	@Override
	public List<Task<? super E>> getRunningTasks() {
		List<Task<? super E>> runningBehaviours = new ObjectArrayList<>();

		for (ActivityBehaviours<E> behaviourGroup : this.behaviours) {
			for (Pair<Activity, List<Task<? super E>>> pair : behaviourGroup.behaviours) {
				for (Task<? super E> behaviour : pair.getSecond()) {
					if (behaviour.getStatus() == MultiTickTask.Status.RUNNING)
						runningBehaviours.add(behaviour);
				}
			}
		}

		return runningBehaviours;
	}

	/**
	 * Returns a stream of all {@link Task Behaviours} registered to this brain
	 */
	public Stream<Task<? super E>> getBehaviours() {
		return this.behaviours.stream().map(ActivityBehaviours::behaviours).flatMap(list -> list.stream().map(Pair::getSecond).flatMap(List::stream));
	}

	@Override
	public void clear() {
		this.behaviours.clear();
	}

	@Override
	public void setTaskList(Activity activity, ImmutableList<? extends Pair<Integer, ? extends Task<? super E>>> tasks, Set<Pair<MemoryModuleType<?>, MemoryModuleState>> memorieStatuses, Set<MemoryModuleType<?>> memoryTypes) {
		this.requiredActivityMemories.put(activity, memorieStatuses);

		if (!memoryTypes.isEmpty())
			this.forgettingActivityMemories.put(activity, memoryTypes);

		for (Pair<Integer, ? extends Task<? super E>> pair : tasks) {
			addBehaviour(pair.getFirst(), activity, pair.getSecond());
		}
	}

	/**
	 * Adds a full {@link BrainActivityGroup} to the brain, inclusive of activities and conditions
	 */
	public void addActivity(BrainActivityGroup<E> activityGroup) {
		setTaskList(activityGroup.getActivity(), activityGroup.pairBehaviourPriorities(), activityGroup.getActivityStartMemoryConditions(), activityGroup.getWipedMemoriesOnFinish());
	}

	/**
	 * Add a behaviour to the behaviours list of this brain.
	 * 
	 * @param priority  The behaviour's priority value
	 * @param activity  The behaviour's activity category
	 * @param behaviour The behaviour instance
	 */
	public void addBehaviour(int priority, Activity activity, Task<? super E> behaviour) {
		for (ActivityBehaviours<E> behaviourGroup : this.behaviours) {
			if (behaviourGroup.priority == priority) {
				for (Pair<Activity, List<Task<? super E>>> pair : behaviourGroup.behaviours) {
					if (pair.getFirst() == activity) {
						pair.getSecond().add(behaviour);

						return;
					}
				}

				behaviourGroup.behaviours.add(Pair.of(activity, ObjectArrayList.of(behaviour)));

				return;
			}
		}

		this.behaviours.add(new ActivityBehaviours<>(priority, ObjectArrayList.of(Pair.of(activity, ObjectArrayList.<Task<? super E>>of(behaviour)))));
		this.sortBehaviours = true;
	}

	/**
	 * Removes any behaviours matching the given predicate from the provided brain.<br>
	 * Removed behaviours are stopped prior to removal
	 * @param entity The owner of the brain
	 * @param predicate The predicate checked for each (priority, activity, behaviour)
	 */
	public void removeBehaviour(E entity, BrainBehaviourPredicate predicate) {
		for (ActivityBehaviours<E> behaviourGroup : this.behaviours) {
			int priority = behaviourGroup.priority;

			for (Pair<Activity, List<Task<? super E>>> pair : behaviourGroup.behaviours) {
				Activity activity = pair.getFirst();

				for (Iterator<Task<? super E>> iterator = pair.getSecond().iterator(); iterator.hasNext();) {
					Task<? super E> behaviour = iterator.next();

					checkBehaviour(priority, activity, behaviour, null, predicate, () -> {
						if (behaviour.getStatus() == MultiTickTask.Status.RUNNING)
							behaviour.stop((ServerWorld)entity.getWorld(), entity, entity.getWorld().getTime());

						iterator.remove();
					});
				}
			}
		}
	}

	/**
	 * Sets a {@link SmartBrainSchedule} for this brain, for scheduled functionality
	 * @param schedule The schedule to set for the brain
	 * @return this
	 */
	public SmartBrain<E> setSchedule(SmartBrainSchedule schedule) {
		this.schedule = schedule;

		return this;
	}

	/**
	 * @return The {@link SmartBrainSchedule schedule} of this brain
	 */
	@Override
	public SmartBrainSchedule getSchedule() {
		return this.schedule;
	}

	/**
	 * Cheekily (and conveniently) uses the {@link SmartBrainSchedule schedule} system to schedule a delayed runnable for this entity/brain.
	 * @param delay The delay (in ticks) before running the task
	 * @param task The task to run at the given tick
	 */
	public void scheduleTask(E brainOwner, int delay, Consumer<E> task) {
		if (this.schedule == null)
			this.schedule = new SmartBrainSchedule();

		this.schedule.scheduleTask(brainOwner, delay, (Consumer)task);
	}

	protected static <E extends LivingEntity> void checkBehaviour(int priority, Activity activity, Task<E> behaviour, @Nullable Task<E> parentBehaviour, BrainBehaviourPredicate predicate, Runnable callback) {
		if (predicate.isBehaviour(priority, activity, behaviour, parentBehaviour)) {
			callback.run();
		}
		else if (behaviour instanceof CompositeTask groupBehaviour) {
			for (Iterator<Task<E>> childBehaviourIterator = groupBehaviour.tasks.iterator(); childBehaviourIterator.hasNext();) {
				checkBehaviour(priority, activity, childBehaviourIterator.next(), groupBehaviour, predicate, childBehaviourIterator::remove);
			}

			if (!groupBehaviour.tasks.iterator().hasNext())
				callback.run();
		}
		else if (behaviour instanceof GroupBehaviour groupBehaviour) {
			for (Iterator<Task<E>> childBehaviourIterator = groupBehaviour.getBehaviours(); childBehaviourIterator.hasNext();) {
				checkBehaviour(priority, activity, childBehaviourIterator.next(), groupBehaviour, predicate, childBehaviourIterator::remove);
			}

			if (!groupBehaviour.getBehaviours().hasNext())
				callback.run();
		}
	}

	/**
	 * Loops over all {@link Task Behaviours} registered to this brain, calling the consumer for each
	 * @param consumer The consumer called for each (priority, activity, behaviour)
	 */
	public void forEachBehaviour(BrainBehaviourConsumer consumer) {
		for (ActivityBehaviours<E> behavioursGroup : this.behaviours) {
			int priority = behavioursGroup.priority();

			for (Pair<Activity, List<Task<? super E>>> behaviourList : behavioursGroup.behaviours()) {
				Activity activity = behaviourList.getFirst();

				for (Task<? super E> behaviour : behaviourList.getSecond()) {
					consumeBehaviour(priority, activity, behaviour, null, consumer);
				}
			}
		}
	}

	protected static <E extends LivingEntity> void consumeBehaviour(int priority, Activity activity, Task<E> behaviour, @Nullable Task<E> parentBehaviour, BrainBehaviourConsumer consumer) {
		consumer.consume(priority, activity, behaviour, parentBehaviour);

		if (behaviour instanceof CompositeTask<E> groupBehaviour) {
			groupBehaviour.tasks.method_35094().forEach(childBehaviour -> consumeBehaviour(priority, activity, (class_7893)childBehaviour, groupBehaviour, consumer));
		}
		else if (behaviour instanceof GroupBehaviour<E> groupBehaviour) {
			groupBehaviour.getBehaviours().forEachRemaining(childBehaviour -> consumeBehaviour(priority, activity, (Task)childBehaviour, groupBehaviour, consumer));
		}
	}

	/**
	 * Adds an {@link ExtendedSensor} to this brain
	 */
	public void addSensor(ExtendedSensor<E> sensor) {
		SensorType<ExtendedSensor<? super E>> sensorType = (SensorType)sensor.type();

		this.sensors.add(Pair.of(sensorType, sensor));
	}

	/**
	 * Not supported, use {@link SmartBrain#setSchedule(SmartBrainSchedule)} instead
	 */
	@Deprecated(forRemoval = true)
	@Override
	public final void setSchedule(Schedule schedule) {}

	protected record ActivityBehaviours<E extends LivingEntity & SmartBrainOwner<E>> (int priority, List<Pair<Activity, List<Task<? super E>>>> behaviours) {}
}
