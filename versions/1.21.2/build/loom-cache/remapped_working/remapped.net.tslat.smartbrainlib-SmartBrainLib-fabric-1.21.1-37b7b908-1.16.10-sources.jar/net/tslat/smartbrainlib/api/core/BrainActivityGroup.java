package net.tslat.smartbrainlib.api.core;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Activity;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.task.MultiTickTask;
import net.tslat.smartbrainlib.api.SmartBrainOwner;

import java.util.List;
import java.util.Set;

public class BrainActivityGroup<T extends LivingEntity & SmartBrainOwner<T>> {
	private final Activity activity;
	private int priorityStart = 0;
	private final List<MultiTickTask<? super T>> behaviours = new ObjectArrayList<>();
	private final Set<Pair<MemoryModuleType<?>, MemoryModuleState>> activityStartMemoryConditions = new ObjectOpenHashSet<>();
	private Set<MemoryModuleType<?>> wipedMemoriesOnFinish = null;

	public BrainActivityGroup(Activity activity) {
		this.activity = activity;
	}

	public BrainActivityGroup<T> priority(int priorityStart) {
		this.priorityStart = priorityStart;

		return this;
	}

	public BrainActivityGroup<T> behaviours(MultiTickTask<? super T>... behaviours) {
		this.behaviours.addAll(new ObjectArrayList<>(behaviours));

		return this;
	}

	public BrainActivityGroup<T> onlyStartWithMemoryStatus(MemoryModuleType<?> memory, MemoryModuleState status) {
		this.activityStartMemoryConditions.add(Pair.of(memory, status));

		return this;
	}

	public BrainActivityGroup<T> wipeMemoriesWhenFinished(MemoryModuleType<?>... memories) {
		if (this.wipedMemoriesOnFinish == null) {
			this.wipedMemoriesOnFinish = new ObjectOpenHashSet<>(memories);
		}
		else {
			this.wipedMemoriesOnFinish.addAll(new ObjectOpenHashSet<>(memories));
		}

		return this;
	}

	public BrainActivityGroup<T> requireAndWipeMemoriesOnUse(MemoryModuleType<?>... memories) {
		for (MemoryModuleType<?> memory : memories) {
			onlyStartWithMemoryStatus(memory, MemoryModuleState.VALUE_PRESENT);
		}

		wipeMemoriesWhenFinished(memories);

		return this;
	}

	public Activity getActivity() {
		return this.activity;
	}

	public List<MultiTickTask<? super T>> getBehaviours() {
		return this.behaviours;
	}

	public int getPriorityStart() {
		return this.priorityStart;
	}

	public Set<Pair<MemoryModuleType<?>, MemoryModuleState>> getActivityStartMemoryConditions() {
		return this.activityStartMemoryConditions;
	}

	public Set<MemoryModuleType<?>> getWipedMemoriesOnFinish() {
		return this.wipedMemoriesOnFinish != null ? this.wipedMemoriesOnFinish : Set.of();
	}

	public ImmutableList<Pair<Integer, MultiTickTask<? super T>>> pairBehaviourPriorities() {
		int priority = this.priorityStart;
		ImmutableList.Builder<Pair<Integer, MultiTickTask<? super T>>> pairedBehaviours = ImmutableList.builder();

		for (MultiTickTask<? super T> behaviour : this.behaviours) {
			pairedBehaviours.add(Pair.of(priority++, behaviour));
		}

		return pairedBehaviours.build();
	}

	public static <T extends LivingEntity & SmartBrainOwner<T>> BrainActivityGroup<T> empty() {
		return new BrainActivityGroup<T>(Activity.REST);
	}

	@SafeVarargs
	public static <T extends LivingEntity & SmartBrainOwner<T>> BrainActivityGroup<T> coreTasks(MultiTickTask... behaviours) {
		return new BrainActivityGroup<T>(Activity.CORE).priority(0).behaviours(behaviours);
	}

	@SafeVarargs
	public static <T extends LivingEntity & SmartBrainOwner<T>> BrainActivityGroup<T> idleTasks(MultiTickTask... behaviours) {
		return new BrainActivityGroup<T>(Activity.IDLE).priority(10).behaviours(behaviours);
	}

	@SafeVarargs
	public static <T extends LivingEntity & SmartBrainOwner<T>> BrainActivityGroup<T> fightTasks(MultiTickTask... behaviours) {
		return new BrainActivityGroup<T>(Activity.FIGHT).priority(10).behaviours(behaviours).requireAndWipeMemoriesOnUse(MemoryModuleType.ATTACK_TARGET);
	}
}
