package net.tslat.smartbrainlib.api.core.sensor;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.LivingTargetCache;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.util.BrainUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiPredicate;

/**
 * An abstract class that is used to pick out certain entities from the existing {@link MemoryModuleType#VISIBLE_MOBS} memory. <br>
 * This requires that another sensor has pre-filled that memory.
 * @see net.minecraft.entity.ai.brain.sensor.NearestVisibleLivingEntitySensor
 * @param <P> The target entity
 * @param <E> The entity
 */
public abstract class EntityFilteringSensor<P, E extends LivingEntity> extends PredicateSensor<LivingEntity, E> {
	/**
	 * Which memory the sensor should set if an entity meets the given criteria.
	 *
	 * @return The memory type to use
	 */
	protected abstract MemoryModuleType<P> getMemory();

	@Override
	protected abstract BiPredicate<LivingEntity, E> predicate();

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return List.of(getMemory());
	}

	@Override
	protected void sense(ServerWorld level, E entity) {
		BrainUtils.setMemory(entity, getMemory(), testForEntity(entity));
	}

	protected P testForEntity(E entity) {
		LivingTargetCache matcher = BrainUtils.getMemory(entity, MemoryModuleType.VISIBLE_MOBS);

		if (matcher == null)
			return null;

		return findMatches(entity, matcher);
	}

	/**
	 * Find and return matches based on the provided list of entities. <br>
	 * The returned value is saved as the memory for this sensor.
	 * @param entity The entity
	 * @param matcher The nearby entities list retrieved from the {@link MemoryModuleType#VISIBLE_MOBS} memory
	 * @return The match(es) to save in memory
	 */
	@Nullable
	protected abstract P findMatches(E entity, LivingTargetCache matcher);
}
