package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiPredicate;

/**
 * A movement behaviour for automatically following the parent of an {@link PassiveEntity AgeableMob}.
 * <p>Note that because vanilla animals do not store a reference to their parent or child, by default this behaviour just grabs the nearest
 * animal of the same class and presumes it is the parent.</p>
 */
public class FollowParent<E extends PassiveEntity> extends FollowEntity<E, PassiveEntity> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(1).hasMemory(MemoryModuleType.VISIBLE_MOBS);

	private BiPredicate<E, PassiveEntity> parentPredicate = (entity, other) -> entity.getClass() == other.getClass() && other.getBreedingAge() >= 0;

	public FollowParent() {
		following(this::getParent);
		stopFollowingWithin(2);
	}

	/**
	 * Set the predicate that determines whether a given entity is a suitable 'parent' to follow
	 */
	public FollowParent<E> parentPredicate(BiPredicate<E, PassiveEntity> predicate) {
		this.parentPredicate = predicate;

		return this;
	}

	@Override
	public List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean checkExtraStartConditions(ServerWorld level, E entity) {
		return entity.getBreedingAge() < 0 && super.checkExtraStartConditions(level, entity);
	}

	@Nullable
	protected PassiveEntity getParent(E entity) {
		return BrainUtils.getMemory(entity, MemoryModuleType.VISIBLE_MOBS).findFirst(other -> other instanceof PassiveEntity ageableMob && this.parentPredicate.test(entity, ageableMob)).map(PassiveEntity.class::cast).orElse(null);
	}
}
