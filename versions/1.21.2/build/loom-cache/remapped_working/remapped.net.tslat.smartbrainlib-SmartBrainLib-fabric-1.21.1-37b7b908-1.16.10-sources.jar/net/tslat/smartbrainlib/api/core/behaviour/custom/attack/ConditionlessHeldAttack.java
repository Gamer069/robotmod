package net.tslat.smartbrainlib.api.core.behaviour.custom.attack;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.task.TargetUtil;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.tslat.smartbrainlib.api.core.behaviour.HeldBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Attack behaviour for held attacks that doesn't require line of sight or proximity to target, or to even have a target at all.
 * This is useful for special attacks.<br>
 * Set the actual condition for activation via {@link net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour#startCondition ExtendedBehaviour.startCondition}
 * @param <E> The entity
 */
public class ConditionlessHeldAttack<E extends LivingEntity> extends HeldBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(1).noMemory(MemoryModuleType.ATTACK_COOLING_DOWN);

	protected boolean requireTarget = false;

	@Nullable
	protected LivingEntity target = null;

	/**
	 * Set that the attack requires that the entity have an attack target set to activate.
	 * @return this
	 */
	public ConditionlessHeldAttack<E> requiresTarget() {
		this.requireTarget = true;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean shouldRun(ServerWorld level, E entity) {
		if (!this.requireTarget)
			return true;

		this.target = BrainUtils.getTargetOfEntity(entity);

		return this.target != null;
	}

	@Override
	protected void start(E entity) {
		entity.swingHand(Hand.MAIN_HAND);

		if (this.requireTarget)
			TargetUtil.lookAt(entity, this.target);
	}

	@Override
	protected void finishRunning(ServerWorld level, E entity, long gameTime) {
		super.finishRunning(level, entity, gameTime);

		this.target = null;
	}
}
