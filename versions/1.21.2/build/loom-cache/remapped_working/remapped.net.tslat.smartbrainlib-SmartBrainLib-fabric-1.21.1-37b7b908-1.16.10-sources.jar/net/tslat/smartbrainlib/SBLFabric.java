package net.tslat.smartbrainlib;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.example.SBLSkeleton;
import net.tslat.smartbrainlib.registry.SBLMemoryTypes;
import net.tslat.smartbrainlib.registry.SBLSensors;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

public final class SBLFabric implements SBLLoader {
	public static EntityType<SBLSkeleton> SBL_SKELETON;

	public void init(Object eventBus) {
		SBLMemoryTypes.init();
		SBLSensors.init();

		if (isDevEnv())
			registerEntities();
	}

	@Override
	public boolean isDevEnv() {
		return FabricLoader.getInstance().isDevelopmentEnvironment();
	}

	@Override
	public Pair<Collection<? extends Entity>, Function<Entity, ? extends Entity>> getPartEntities(World level) {
		return Pair.of(List.of(), Function.identity());
	}

	@Override
	public <T> Supplier<MemoryModuleType<T>> registerMemoryType(String id) {
		return registerMemoryType(id, Optional.empty());
	}

	@Override
	public <T> Supplier<MemoryModuleType<T>> registerMemoryType(String id, Optional<Codec<T>> codec) {
		MemoryModuleType<T> memoryType = Registry.register(Registries.MEMORY_MODULE_TYPE, Identifier.of(SBLConstants.MOD_ID, id), new MemoryModuleType<>(codec));

		return () -> memoryType;
	}

	@Override
	public <T extends ExtendedSensor<?>> Supplier<SensorType<T>> registerSensorType(String id, Supplier<T> sensor) {
		SensorType<T> sensorType = Registry.register(Registries.SENSOR_TYPE, Identifier.of(SBLConstants.MOD_ID, id), new SensorType<>(sensor));

		return () -> sensorType;
	}

	private static void registerEntities() {
		SBL_SKELETON = Registry.register(Registries.ENTITY_TYPE, Identifier.of(SBLConstants.MOD_ID, "sbl_skeleton"), FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, SBLSkeleton::new).dimensions(EntityDimensions.changing(0.6f, 1.99f)).build());

		FabricDefaultAttributeRegistry.register(SBL_SKELETON, SkeletonEntity.createAbstractSkeletonAttributes());
	}
}
