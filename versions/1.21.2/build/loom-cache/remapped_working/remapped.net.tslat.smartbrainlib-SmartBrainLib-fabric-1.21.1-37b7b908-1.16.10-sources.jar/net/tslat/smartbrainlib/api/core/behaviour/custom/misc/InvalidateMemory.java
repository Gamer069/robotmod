package net.tslat.smartbrainlib.api.core.behaviour.custom.misc;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtils;

import java.util.List;
import java.util.function.BiPredicate;

/**
 * Custom behaviour for conditionally invalidating/resetting existing memories.<br>
 * This allows for custom handling of stored memories, and clearing them at will.<br>
 * <br>
 * Invalidates the memory unconditionally once the behaviour runs. Use {@link InvalidateMemory#invalidateIf} and {@link ExtendedBehaviour#startCondition} to quantify its operating conditions
 * @param <E> The brain owner
 * @param <M> The data type of the memory
 */
public class InvalidateMemory<E extends LivingEntity, M> extends ExtendedBehaviour<E> {
	private List<Pair<MemoryModuleType<?>, MemoryModuleState>> memoryRequirements;

	protected BiPredicate<E, M> customPredicate = (entity, target) -> true;
	protected MemoryModuleType<M> memory;

	public InvalidateMemory(MemoryModuleType<M> memory) {
		super();

		this.memory = memory;
		this.memoryRequirements = MemoryTest.builder(1).hasMemory(this.memory);
	}

	/**
	 * Sets the {@link MemoryModuleType memory} to check and invalidate.
	 * @deprecated Use the constructor
	 */
	@Deprecated(forRemoval = true)
	public InvalidateMemory<E, M> forMemory(MemoryModuleType<M> memory) {
		this.memory = memory;
		this.memoryRequirements = MemoryTest.builder(1).hasMemory(memory);

		return this;
	}

	/**
	 * Sets a custom predicate to invalidate the memory if none of the previous checks invalidate it first.
	 */
	public InvalidateMemory<E, M> invalidateIf(BiPredicate<E, M> predicate) {
		this.customPredicate = predicate;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return this.memoryRequirements == null ? List.of() : this.memoryRequirements;
	}

	@Override
	protected void start(E entity) {
		M memory = BrainUtils.getMemory(entity, this.memory);

		if (memory != null && this.customPredicate.test(entity, memory))
			BrainUtils.clearMemory(entity, this.memory);
	}
}
