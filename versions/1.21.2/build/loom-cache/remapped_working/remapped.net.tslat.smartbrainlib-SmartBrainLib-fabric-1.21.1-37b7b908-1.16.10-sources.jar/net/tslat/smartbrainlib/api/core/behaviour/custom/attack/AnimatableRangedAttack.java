package net.tslat.smartbrainlib.api.core.behaviour.custom.attack;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.RangedAttackMob;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.task.TargetUtil;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.world.Difficulty;
import net.tslat.smartbrainlib.api.core.behaviour.DelayedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Function;

/**
 * Extended behaviour for ranged attacking. Natively supports animation hit delays or other delays.
 * Defaults:
 * <ul>
 *     <li>40-tick firing interval, decreased to 20 ticks when on {@link Difficulty Hard Difficulty}</li>
 *     <li>16-block firing radius</li>
 * </ul>
 * @param <E>
 */
public class AnimatableRangedAttack<E extends LivingEntity & RangedAttackMob> extends DelayedBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(2).hasMemory(MemoryModuleType.ATTACK_TARGET).noMemory(MemoryModuleType.ATTACK_COOLING_DOWN);

	protected Function<E, Integer> attackIntervalSupplier = entity -> entity.getWorld().getDifficulty() == Difficulty.HARD ? 20 : 40;
	protected float attackRadius;

	@Nullable
	protected LivingEntity target = null;

	public AnimatableRangedAttack(int delayTicks) {
		super(delayTicks);

		attackRadius(16);
	}

	/**
	 * Set the time between attacks.
	 * @param supplier The tick value provider
	 * @return this
	 */
	public AnimatableRangedAttack<E> attackInterval(Function<E, Integer> supplier) {
		this.attackIntervalSupplier = supplier;

		return this;
	}

	/**
	 * Set the radius in blocks that the entity should be able to fire on targets.
	 * @param radius The radius, in blocks
	 * @return this
	 */
	public AnimatableRangedAttack<E> attackRadius(float radius) {
		this.attackRadius = radius * radius;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean shouldRun(ServerWorld level, E entity) {
		this.target = BrainUtils.getTargetOfEntity(entity);

		return BrainUtils.canSee(entity, this.target) && entity.squaredDistanceTo(this.target) <= this.attackRadius;
	}

	@Override
	protected void start(E entity) {
		entity.swingHand(Hand.MAIN_HAND);
		TargetUtil.lookAt(entity, this.target);
	}

	@Override
	protected void stop(E entity) {
		this.target = null;
	}

	@Override
	protected void doDelayedAction(E entity) {
		if (this.target == null)
			return;

		if (!BrainUtils.canSee(entity, this.target) || entity.squaredDistanceTo(this.target) > this.attackRadius)
			return;

		entity.shootAt(this.target, 1);
		BrainUtils.setForgettableMemory(entity, MemoryModuleType.ATTACK_COOLING_DOWN, true, this.attackIntervalSupplier.apply(entity));
	}
}
