package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.mob.PathAwareEntity;
import net.tslat.smartbrainlib.util.BrainUtils;

/**
 * Extension of MoveToWalkTarget, but auto-marking the sprinting flag depending on the movespeed.
 * This can be useful for using sprint animations on the client.
 * @param <E>
 */
public class WalkOrRunToWalkTarget<E extends PathAwareEntity> extends MoveToWalkTarget<E> {
	@Override
	protected void startOnNewPath(E entity) {
		BrainUtils.setMemory(entity, MemoryModuleType.PATH, this.path);

		if (entity.getNavigation().startMovingAlong(this.path, this.speedModifier))
			entity.setFlag(3, this.speedModifier > 1);
	}

	@Override
	protected void stop(E entity) {
		super.stop(entity);

		entity.setFlag(3, false);
	}
}