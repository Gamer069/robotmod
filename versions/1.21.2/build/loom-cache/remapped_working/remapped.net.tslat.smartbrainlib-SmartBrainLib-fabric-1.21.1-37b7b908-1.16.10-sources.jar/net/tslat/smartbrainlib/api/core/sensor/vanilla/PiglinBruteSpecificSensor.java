package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.AbstractPiglinEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtils;

import java.util.List;

/**
 * A replication of vanilla's
 * {@link net.minecraft.entity.ai.brain.sensor.PiglinBruteSpecificSensor}. Not
 * really useful, but included for completeness' sake and legibility. <br>
 * Keeps track of nearby {@link PiglinEntity piglins} and
 * {@link MemoryModuleType#NEAREST_VISIBLE_NEMESIS nemesis}
 * 
 * @param <E> The entity
 */
public class PiglinBruteSpecificSensor<E extends LivingEntity> extends ExtendedSensor<E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(MemoryModuleType.NEARBY_ADULT_PIGLINS);

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.PIGLIN_BRUTE_SPECIFIC.get();
	}

	@Override
	protected void sense(ServerWorld level, E entity) {
		Brain<?> brain = entity.getBrain();
		List<AbstractPiglinEntity> nearbyPiglins = new ObjectArrayList<>();

		BrainUtils.withMemory(brain, MemoryModuleType.VISIBLE_MOBS, entities -> BrainUtils.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_NEMESIS, (MobEntity)entities.findFirst(target -> target instanceof WitherSkeletonEntity || target instanceof WitherEntity).orElse(null)));
		BrainUtils.withMemory(brain, MemoryModuleType.MOBS, entities -> {
			for (LivingEntity target : entities) {
				if (target instanceof AbstractPiglinEntity piglin && piglin.isAdult())
					nearbyPiglins.add(piglin);
			}
		});
		BrainUtils.setMemory(brain, MemoryModuleType.NEARBY_ADULT_PIGLINS, nearbyPiglins);
	}
}
