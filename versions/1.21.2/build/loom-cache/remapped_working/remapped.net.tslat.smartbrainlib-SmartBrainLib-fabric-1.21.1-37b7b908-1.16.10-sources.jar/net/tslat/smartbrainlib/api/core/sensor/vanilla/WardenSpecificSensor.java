package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtils;

import java.util.List;

/**
 * A replication of vanilla's {@link net.minecraft.entity.ai.brain.sensor.WardenAttackablesSensor}. Not really useful, but included for completeness' sake and legibility. <br>
 * Handle's the Warden's nearest attackable target, prioritising players.
 * @param <E> The entity
 */
public class WardenSpecificSensor<E extends WardenEntity> extends NearbyLivingEntitySensor<E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(MemoryModuleType.NEAREST_ATTACKABLE);

	public WardenSpecificSensor() {
		setRadius(24);
		setPredicate((target, entity) -> entity.isValidTarget(target));
	}

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.WARDEN_SPECIFIC.get();
	}

	@Override
	protected void doTick(ServerWorld level, E entity) {
		super.sense(level, entity);

		BrainUtils.withMemory(entity, MemoryModuleType.MOBS, entities -> {
			LivingEntity fallbackTarget = null;

			for (LivingEntity target : entities) {
				if (target instanceof PlayerEntity) {
					BrainUtils.setMemory(entity, MemoryModuleType.NEAREST_ATTACKABLE, target);

					return;
				}
				else if (fallbackTarget == null) {
					fallbackTarget = target;
				}
			}

			if (fallbackTarget != null) {
				BrainUtils.setMemory(entity, MemoryModuleType.NEAREST_ATTACKABLE, fallbackTarget);
			}
			else {
				BrainUtils.clearMemory(entity, MemoryModuleType.NEAREST_ATTACKABLE);
			}
		});
	}
}
