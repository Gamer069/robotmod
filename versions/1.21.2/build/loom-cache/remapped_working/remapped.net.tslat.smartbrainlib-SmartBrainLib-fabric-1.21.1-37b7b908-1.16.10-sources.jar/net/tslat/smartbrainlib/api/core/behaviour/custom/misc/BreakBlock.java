package net.tslat.smartbrainlib.api.core.behaviour.custom.misc;

import com.mojang.datafixers.util.Pair;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldEvents;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.object.TriPredicate;
import net.tslat.smartbrainlib.registry.SBLMemoryTypes;
import net.tslat.smartbrainlib.util.BrainUtils;
import org.apache.commons.lang3.function.TriFunction;

import java.util.List;

/**
 * Gradually breaks then destroys a block. <br>
 * Finds blocks based on the {@link SBLMemoryTypes#NEARBY_BLOCKS} memory module. <br>
 * Defaults:
 * <ul>
 *     <li>Breaks doors</li>
 *     <li>Takes 240 ticks to break the block</li>
 * </ul>
 */
public class BreakBlock<E extends LivingEntity> extends ExtendedBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(1).hasMemory(SBLMemoryTypes.NEARBY_BLOCKS.get());

	protected TriPredicate<E, BlockPos, BlockState> targetBlockPredicate = (entity, pos, state) -> state.isIn(BlockTags.DOORS);
	protected TriPredicate<E, BlockPos, BlockState> stopPredicate = (entity, pos, state) -> false;
	protected TriFunction<E, BlockPos, BlockState, Integer> digTimePredicate = (entity, pos, state) -> 240;

	protected BlockPos pos = null;
	protected BlockState state = null;
	protected int timeToBreak = 0;
	protected int breakTime = 0;
	protected int breakProgress = -1;

	/**
	 * Set the condition for when the entity should stop breaking the block.
	 * @param predicate The predicate
	 * @return this
	 */
	public BreakBlock<E> stopBreakingIf(TriPredicate<E, BlockPos, BlockState> predicate) {
		this.stopPredicate = predicate;

		return this;
	}

	/**
	 * Sets the predicate for valid blocks to break.
	 * @param predicate The predicate
	 * @return this
	 */
	public BreakBlock<E> forBlocks(TriPredicate<E, BlockPos, BlockState> predicate) {
		this.targetBlockPredicate = predicate;

		return this;
	}

	/**
	 * Determines the amount of time (in ticks) it takes to break the given block.
	 * @param function The function
	 * @return this
	 */
	public BreakBlock<E> timeToBreak(TriFunction<E, BlockPos, BlockState, Integer> function) {
		this.digTimePredicate = function;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean isTimeLimitExceeded(long gameTime) {
		return this.breakProgress < 0 && super.isTimeLimitExceeded(gameTime);
	}

	@Override
	protected void stop(E entity) {
		entity.getWorld().setBlockBreakingInfo(entity.getId(), this.pos, -1);

		this.state = null;
		this.pos = null;
		this.timeToBreak = 0;
		this.breakTime = 0;
		this.breakProgress = -1;
	}

	@Override
	protected boolean shouldRun(ServerWorld level, E entity) {
		for (Pair<BlockPos, BlockState> pair : BrainUtils.getMemory(entity, SBLMemoryTypes.NEARBY_BLOCKS.get())) {
			if (this.targetBlockPredicate.test(entity, pair.getFirst(), pair.getSecond())) {
				this.pos = pair.getFirst();
				this.state = pair.getSecond();
				this.timeToBreak = this.digTimePredicate.apply(entity, this.pos, this.state);

				return true;
			}
		}

		return false;
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		return this.breakTime <= this.timeToBreak && this.targetBlockPredicate.test(entity, this.pos, entity.getWorld().getBlockState(this.pos)) && !this.stopPredicate.test(entity, this.pos, this.state);
	}

	@Override
	protected void tick(E entity) {
		this.breakTime++;
		int progress = (int)(this.breakTime / (float)this.timeToBreak * 10);

		if (progress != this.breakProgress) {
			entity.getWorld().setBlockBreakingInfo(entity.getId(), this.pos, progress);

			this.breakProgress = progress;
		}

		if (this.breakTime >= this.timeToBreak) {
			entity.getWorld().removeBlock(this.pos, false);
			entity.getWorld().syncWorldEvent(WorldEvents.BLOCK_BROKEN, this.pos, Block.getRawIdFromState(entity.getWorld().getBlockState(this.pos)));

			stop((ServerWorld)entity.getWorld(), entity, entity.getWorld().getTime());
		}
	}
}