package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Tameable;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.world.entity.*;

/**
 * A movement behaviour for automatically following the owner of a {@link TameableEntity TameableAnimal}
 *
 * @param <E> The owner of the brain
 */
public class FollowOwner<E extends PathAwareEntity & Tameable> extends FollowEntity<E, LivingEntity> {
	public FollowOwner() {
		following(Tameable::getOwner);
		teleportToTargetAfter(12);
	}
}