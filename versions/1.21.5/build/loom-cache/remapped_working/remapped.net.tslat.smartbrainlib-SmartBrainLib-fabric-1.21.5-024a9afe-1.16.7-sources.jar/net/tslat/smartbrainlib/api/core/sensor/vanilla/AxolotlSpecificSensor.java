package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.LivingTargetCache;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.Sensor;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.sensor.EntityFilteringSensor;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiPredicate;

/**
 * A replication of vanilla's
 * {@link net.minecraft.entity.ai.brain.sensor.AxolotlAttackablesSensor}. Not
 * really useful, but included for completeness' sake and legibility. <br>
 * Handles the Axolotl's hostility and targets
 * 
 * @param <E> The entity
 */
public class AxolotlSpecificSensor<E extends LivingEntity> extends EntityFilteringSensor<LivingEntity, E> {
	@Override
	public MemoryModuleType<LivingEntity> getMemory() {
		return MemoryModuleType.NEAREST_ATTACKABLE;
	}

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return List.of(getMemory(), MemoryModuleType.VISIBLE_MOBS);
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.AXOLOTL_SPECIFIC.get();
	}

	@Override
	protected BiPredicate<LivingEntity, E> predicate() {
		return (target, entity) -> {
			if (target.squaredDistanceTo(entity) > 64)
				return false;

			if (!target.isTouchingWater())
				return false;

			if (!target.getType().isIn(EntityTypeTags.AXOLOTL_ALWAYS_HOSTILES) && (BrainUtil.hasMemory(target, MemoryModuleType.HAS_HUNTING_COOLDOWN) || !target.getType().isIn(EntityTypeTags.AXOLOTL_HUNT_TARGETS)))
				return false;

			return Sensor.testAttackableTargetPredicate((ServerWorld)entity.getWorld(), entity, target);
		};
	}

	@Nullable
	@Override
	protected LivingEntity findMatches(E entity, LivingTargetCache matcher) {
		return matcher.findFirst(target -> predicate().test(target, entity)).orElse(null);
	}
}
