package net.tslat.smartbrainlib.api.core.behaviour.custom.misc;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.pathing.MobNavigation;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;

import java.util.List;

/** Avoid the sun if not wearing a hat
 * @param <E> The entity
 */
public class AvoidSun<E extends PathAwareEntity> extends ExtendedBehaviour<E> {
	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return List.of();
	}

	@Override
	protected boolean checkExtraStartConditions(ServerWorld level, E entity) {
		return level.isDay() && entity.getEquippedStack(EquipmentSlot.HEAD).isEmpty() && entity.getNavigation() instanceof MobNavigation;
	}

	@Override
	protected void start(E entity) {
		((MobNavigation)entity.getNavigation()).setAvoidSunlight(true);
	}

	@Override
	protected void stop(E entity) {
		if (entity.getNavigation() instanceof MobNavigation groundNavigation)
			groundNavigation.setAvoidSunlight(true);
	}
}
