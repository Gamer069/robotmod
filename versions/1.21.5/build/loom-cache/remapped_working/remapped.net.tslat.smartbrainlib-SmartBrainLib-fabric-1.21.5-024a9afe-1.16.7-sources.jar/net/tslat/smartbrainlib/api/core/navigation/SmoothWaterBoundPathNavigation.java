package net.tslat.smartbrainlib.api.core.navigation;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.ai.pathing.PathNodeNavigator;
import net.minecraft.entity.ai.pathing.SwimNavigation;
import net.minecraft.entity.ai.pathing.WaterPathNodeMaker;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Extension of the vanilla {@link SwimNavigation} navigator with some tweaks for smoother pathfinding:
 * <ul>
 *     <li>Smoothed unit rounding to better accommodate edge-cases</li>
 *     <li>Patched {@link Path} implementation to use proper rounding</li>
 *     <li>Extensible {@link #canBreach()} implementation for ease-of-use</li>
 * </ul>
 * <p>
 * Override {@link MobEntity#createNavigation(World)} and return a new instance of this if your entity is a water-based swimming entity
 */
public class SmoothWaterBoundPathNavigation extends SwimNavigation implements ExtendedNavigator {
    public SmoothWaterBoundPathNavigation(MobEntity mob, World level) {
        super(mob, level);
    }

    /**
     * Determine whether the entity can breach the surface as part of its pathing
     * <p>
     * Defaults to false for non-dolphins
     */
    public boolean canBreach() {
        return this.entity.getType() == EntityType.DOLPHIN;
    }

    @Override
    public MobEntity getMob() {
        return this.entity;
    }

    @Nullable
    @Override
    public Path getCurrentPath() {
        return super.getCurrentPath();
    }

    /**
     * Patch {@link Path#getNodePosition} to use a proper rounding check
     */
    @Override
    protected PathNodeNavigator createPathNodeNavigator(int maxVisitedNodes) {
        this.nodeMaker = new WaterPathNodeMaker(this.canJumpOutOfWater = canBreach());
        this.nodeMaker.setCanEnterOpenDoors(true);

        return createSmoothPathFinder(this.nodeMaker, maxVisitedNodes);
    }
}
