package net.tslat.smartbrainlib.object;

import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.LivingTargetCache;
import net.tslat.smartbrainlib.util.SensoryUtil;

import java.util.List;
import java.util.function.Predicate;

/**
 * Wrapper for {@link LivingTargetCache} that supports follow range for entities rather than a hardcoded 16-block limit
 */
public class FixedNearestVisibleLivingEntities extends LivingTargetCache {
    private FixedNearestVisibleLivingEntities() {
        super();
    }

    public FixedNearestVisibleLivingEntities(LivingEntity entity, List<LivingEntity> entities) {
        super();

        this.entities = entities;
        this.targetPredicate = new Predicate<>() {
            final Object2BooleanOpenHashMap<LivingEntity> cache = new Object2BooleanOpenHashMap<>(entities.size());

            @Override
            public boolean test(LivingEntity target) {
                return this.cache.computeIfAbsent(target, (Predicate<LivingEntity>)target1 -> SensoryUtil.isEntityTargetable(entity, target1));
            }
        };
    }

    public static FixedNearestVisibleLivingEntities empty() {
        return new FixedNearestVisibleLivingEntities();
    }
}
