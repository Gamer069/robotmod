package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.api.core.sensor.PredicateSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;

import java.util.List;

/**
 * A sensor that sets the memory state for the last damage source and attacker.
 *
 * @param <E> The entity
 */
public class HurtBySensor<E extends MobEntity> extends PredicateSensor<DamageSource, E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(MemoryModuleType.HURT_BY, MemoryModuleType.HURT_BY_ENTITY);

	public HurtBySensor() {
		super((damageSource, entity) -> true);
	}

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.HURT_BY.get();
	}

	@Override
	protected void doTick(ServerWorld level, E entity) {
		Brain<?> brain = entity.getBrain();
		DamageSource damageSource = entity.getRecentDamageSource();

		if (damageSource == null) {
			BrainUtil.clearMemory(brain, MemoryModuleType.HURT_BY);
			BrainUtil.clearMemory(brain, MemoryModuleType.HURT_BY_ENTITY);
		}
		else if (predicate().test(damageSource, entity)) {
			BrainUtil.setMemory(brain, MemoryModuleType.HURT_BY, damageSource);

			if (damageSource.getAttacker()instanceof LivingEntity attacker && attacker.isAlive() && attacker.getWorld() == entity.getWorld())
				BrainUtil.setMemory(brain, MemoryModuleType.HURT_BY_ENTITY, attacker);
		}
		else {
			BrainUtil.withMemory(brain, MemoryModuleType.HURT_BY_ENTITY, attacker -> {
				if (!attacker.isAlive() || attacker.getWorld() != entity.getWorld())
					BrainUtil.clearMemory(brain, MemoryModuleType.HURT_BY_ENTITY);
			});
		}
	}
}
