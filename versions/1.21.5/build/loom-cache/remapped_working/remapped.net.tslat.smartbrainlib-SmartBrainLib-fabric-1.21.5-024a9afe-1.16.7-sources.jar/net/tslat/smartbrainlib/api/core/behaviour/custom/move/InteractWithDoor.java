package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.ai.pathing.PathNode;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.GlobalPos;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.object.TriPredicate;
import net.tslat.smartbrainlib.util.BrainUtil;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.ToIntFunction;

/**
 * SmartBrainLib equivalent of vanilla's {@link net.minecraft.entity.ai.brain.task.OpenDoorsTask}
 * <p>
 * By default, it causes entities who are traversing a doorway to open an interceding door, then close it once it has walked through,
 * without interrupting the path.
 * It will also hold the door open if other entities are traversing the doorway at the same time
 * <p>
 * Defaults:
 * <ul>
 *     <li>Holds doors open for entities of the same type within 2 blocks of the door</li>
 * </ul>
 */
public class InteractWithDoor<E extends LivingEntity> extends ExtendedBehaviour<E> {
    private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(3).hasMemory(MemoryModuleType.PATH).usesMemories(MemoryModuleType.DOORS_TO_CLOSE, MemoryModuleType.MOBS);

    protected ToIntFunction<E> doorInteractionDelay = entity -> 20;
    protected TriPredicate<E, LivingEntity, BlockPos> holdDoorsOpenFor = (entity, other, doorPos) -> entity.getType() == other.getType() && doorPos.isWithinDistance(other.getPos(), 2);

    protected int doorCloseCooldown = -1;
    protected PathNode lastNode = null;

    /**
     * Set the predicate that determines what other entities this entity will hold open a door for and under what conditions
     *
     * @param predicate The predicate to test when checking whether an entity should have the door held open for it
     * @return this
     */
    public InteractWithDoor<E> holdDoorsOpenFor(TriPredicate<E, LivingEntity, BlockPos> predicate) {
        this.holdDoorsOpenFor = predicate;

        return this;
    }

    /**
     * Set the tick delay between moving to/away from a door and interacting with it.
     * <p>
     * This should be considered more of a guideline than a hard-and-fast rule
     *
     * @param delay The time between traversing to/from a door, and interacting with it, in ticks
     * @return this
     */
    public InteractWithDoor<E> doorInteractionDelay(ToIntFunction<E> delay) {
        this.doorInteractionDelay = delay;

        return this;
    }

    @Override
    protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
        return MEMORY_REQUIREMENTS;
    }

    @Override
    protected boolean shouldRun(ServerWorld level, E entity) {
        Path path = BrainUtil.getMemory(entity, MemoryModuleType.PATH);

        return !path.isStart() && !path.isFinished();
    }

    @Override
    protected boolean shouldKeepRunning(E entity) {
        return BrainUtil.hasMemory(entity, MemoryModuleType.PATH) && shouldRun((ServerWorld)entity.getWorld(), entity);
    }

    @Override
    protected void tick(E entity) {
        ServerWorld level = (ServerWorld)entity.getWorld();
        Path path = BrainUtil.getMemory(entity, MemoryModuleType.PATH);
        BlockPos prevNodePos = path.getLastNode().getBlockPos();
        BlockPos nextNodePos = path.getCurrentNode().getBlockPos();
        BlockState prevNodeBlockState = level.getBlockState(prevNodePos);
        BlockState nextNodeBlockState = level.getBlockState(nextNodePos);

        if (this.doorCloseCooldown < 0) {
            this.doorCloseCooldown = this.doorInteractionDelay.applyAsInt(entity);
            this.lastNode = path.getCurrentNode();
        }

        if (!Objects.equals(this.lastNode, path.getCurrentNode()) && --this.doorCloseCooldown < 0)
            return;

        BrainUtil.withMemory(entity, MemoryModuleType.DOORS_TO_CLOSE, doorsToClose -> checkAndCloseDoors(level, entity, doorsToClose, prevNodePos, nextNodePos));

        if (isInteractableDoor(prevNodeBlockState))
            tryOpenDoor(level, entity, prevNodeBlockState, prevNodePos);

        if (isInteractableDoor(nextNodeBlockState))
            tryOpenDoor(level, entity, nextNodeBlockState, nextNodePos);
    }

    protected void checkAndCloseDoors(ServerWorld level, E entity, Set<GlobalPos> doorsToClose, BlockPos prevNodePos, BlockPos nextNodePos) {
        for (Iterator<GlobalPos> iterator = doorsToClose.iterator(); iterator.hasNext();) {
            GlobalPos doorLocation = iterator.next();
            BlockPos doorPos = doorLocation.pos();

            if (doorPos.equals(prevNodePos) || doorPos.equals(nextNodePos))
                continue;

            if (doorLocation.dimension() != level.getRegistryKey() || !doorPos.isWithinDistance(entity.getPos(), 3)) {
                iterator.remove();

                continue;
            }

            BlockState doorState = level.getBlockState(doorPos);

            if (isInteractableDoor(doorState)) {
                DoorBlock doorBlock = (DoorBlock)doorState.getBlock();

                if (doorBlock.isOpen(doorState) && !shouldHoldDoorOpenForOthers(entity, doorPos, BrainUtil.memoryOrDefault(entity, MemoryModuleType.MOBS, List::of)))
                    doorBlock.setOpen(entity, level, doorState, doorPos, false);
            }

            iterator.remove();
        }
    }

    protected boolean shouldHoldDoorOpenForOthers(E entity, BlockPos doorPos, List<LivingEntity> others) {
        for (LivingEntity other : others) {
            if (!this.holdDoorsOpenFor.test(entity, other, doorPos))
                continue;

            Path path = BrainUtil.getMemory(entity, MemoryModuleType.PATH);

            if (path == null || path.isFinished() || path.isStart())
                continue;

            if (path.getLastNode().getBlockPos().equals(doorPos) || path.getCurrentNode().getBlockPos().equals(doorPos))
                return true;
        }

        return false;
    }

    protected boolean isInteractableDoor(BlockState state) {
        return state.isIn(BlockTags.MOB_INTERACTABLE_DOORS) && state.getBlock() instanceof DoorBlock;
    }

    protected void tryOpenDoor(ServerWorld level, E entity, BlockState blockState, BlockPos pos) {
        DoorBlock door = (DoorBlock)blockState.getBlock();

        if (!door.isOpen(blockState)) {
            door.setOpen(entity, level, blockState, pos, true);

            Set<GlobalPos> doorPositions = BrainUtil.getMemory(entity, MemoryModuleType.DOORS_TO_CLOSE);

            if (doorPositions == null)
                doorPositions = new ObjectOpenHashSet<>();

            doorPositions.add(new GlobalPos(level.getRegistryKey(), pos));
        }
    }
}
