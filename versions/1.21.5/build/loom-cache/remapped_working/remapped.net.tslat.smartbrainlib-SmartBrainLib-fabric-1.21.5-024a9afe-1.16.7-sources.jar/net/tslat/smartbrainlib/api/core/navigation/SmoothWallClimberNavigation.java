package net.tslat.smartbrainlib.api.core.navigation;

import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.ai.pathing.LandPathNodeMaker;
import net.minecraft.entity.ai.pathing.MobNavigation;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.ai.pathing.PathNodeNavigator;
import net.minecraft.entity.ai.pathing.SpiderNavigation;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Extension of the vanilla {@link SpiderNavigation} with some tweaks for smoother pathfinding:
 * <ul>
 *     <li>Patched {@link Path} implementation to use proper rounding</li>
 *     <li>Accessible {@link MobNavigation#getPathfindingY()} override for extensibility</li>
 * </ul>
 * <p>
 * Override {@link MobEntity#createNavigation(World)} and return a new instance of this if your entity is a ground-based walking entity
 */
public class SmoothWallClimberNavigation extends SpiderNavigation implements ExtendedNavigator {
    public SmoothWallClimberNavigation(MobEntity mob, World level) {
        super(mob, level);
    }

    @Override
    public MobEntity getMob() {
        return this.entity;
    }

    @Nullable
    @Override
    public Path getCurrentPath() {
        return super.getCurrentPath();
    }

    /**
     * Patch {@link Path#getNodePosition} to use a proper rounding check
     */
    @Override
    protected PathNodeNavigator createPathNodeNavigator(int maxVisitedNodes) {
        this.nodeMaker = new LandPathNodeMaker();
        this.nodeMaker.setCanEnterOpenDoors(true);

        return createSmoothPathFinder(this.nodeMaker, maxVisitedNodes);
    }

    /**
     * Helper override to allow end-users to modify the fluids an entity can swim in
     * <p>
     * If using this to modify swimmable fluids, ensure you also override {@link EntityNavigation#isAtValidPosition()} as well
     *
     * @return The nearest safe surface height for the entity
     */
    @Override
    public int getPathfindingY() {
        return super.getPathfindingY();
    }
}
