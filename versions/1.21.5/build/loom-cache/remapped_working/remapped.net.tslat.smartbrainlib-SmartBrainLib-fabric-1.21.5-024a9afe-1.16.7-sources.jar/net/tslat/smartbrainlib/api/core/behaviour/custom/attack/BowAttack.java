package net.tslat.smartbrainlib.api.core.behaviour.custom.attack;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.RangedAttackMob;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.task.TargetUtil;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.BowItem;
import net.minecraft.item.Items;
import net.tslat.smartbrainlib.util.BrainUtil;

/**
 * Extended behaviour for charging and firing a
 * {@link BowItem bow}.
 * 
 * @param <E>
 */
public class BowAttack<E extends LivingEntity & RangedAttackMob> extends AnimatableRangedAttack<E> {
	public BowAttack(int delayTicks) {
		super(delayTicks);
	}

	@Override
	protected void start(E entity) {
		TargetUtil.lookAt(entity, this.target);
		entity.setCurrentHand(ProjectileUtil.getHandPossiblyHolding(entity, Items.BOW));
	}

	@Override
	protected void doDelayedAction(E entity) {
		if (this.target == null)
			return;

		if (!BrainUtil.canSee(entity, this.target) || entity.squaredDistanceTo(this.target) > this.attackRadius)
			return;

		entity.shootAt(this.target, BowItem.getPullProgress(entity.getItemUseTime()));
		entity.clearActiveItem();
		BrainUtil.setForgettableMemory(entity, MemoryModuleType.ATTACK_COOLING_DOWN, true, this.attackIntervalSupplier.applyAsInt(entity));
	}
}
