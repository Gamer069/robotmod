package net.tslat.smartbrainlib.api.core.sensor;

import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.Sensor;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.server.world.ServerWorld;

/**
 * An extension of the base Sensor. This adds some minor additional functionality and swaps the memory to a list for easier usage and faster iteration. <br>
 * All custom sensor implementations should use this superclass.
 *
 * @param <E> The entity
 */
public abstract class ExtendedSensor<E extends LivingEntity> extends Sensor<E> {
	protected ToIntFunction<E> scanRate = entity -> 20;
	protected Consumer<E> scanCallback = entity -> {};
	protected long nextTickTime = 0;

	public ExtendedSensor() {
		super();
	}

	/**
	 * Set the scan rate provider for this sensor. <br>
	 * The provider will be sampled every time the sensor does a scan.
	 *
	 * @param function The function to provide the tick rate
	 * @return this
	 */
	public ExtendedSensor<E> setScanRate(ToIntFunction<E> function) {
		this.scanRate = function;

		return this;
	}

	/**
	 * Set a callback function for when the sensor completes a scan.
	 */
	public ExtendedSensor<E> afterScanning(Consumer<E> callback) {
		this.scanCallback = callback;

		return this;
	}

	@Override
	public final void tick(ServerWorld level, E entity) {
		if (nextTickTime < level.getTime()) {
			nextTickTime = level.getTime() + this.scanRate.applyAsInt(entity);

			sense(level, entity);
			this.scanCallback.accept(entity);
		}
	}

	/**
	 * Handle the Sensor's actual function here. Be wary of performance implications of computation-heavy checks here.
	 *
	 * @param level The level the entity is in
	 * @param entity The owner of the brain
	 */
	@Override
	protected void sense(ServerWorld level, E entity) {}

	/**
	 * The list of memory types this sensor saves to. This should contain any memory the sensor sets a value for in the brain <br>
	 * Bonus points if it's a statically-initialised list.
	 *
	 * @return The list of memory types saves by this sensor
	 */
	public abstract List<MemoryModuleType<?>> memoriesUsed();

	/**
	 * The {@link SensorType} of the sensor, used for reverse lookups.
	 * @return The sensor type
	 */
	public abstract SensorType<? extends ExtendedSensor<?>> type();

	/**
	 * Vanilla's implementation of the required memory collection. Functionally replaced by {@link ExtendedSensor#memoriesUsed()}. <br>
	 * Left in place for compatibility reasons.
	 *
	 * @return A set view of the list returned by {@code memoriesUsed()}
	 */
	@Override
	public final Set<MemoryModuleType<?>> getOutputMemoryModules() {
		return new ObjectOpenHashSet<>(memoriesUsed());
	}
}
