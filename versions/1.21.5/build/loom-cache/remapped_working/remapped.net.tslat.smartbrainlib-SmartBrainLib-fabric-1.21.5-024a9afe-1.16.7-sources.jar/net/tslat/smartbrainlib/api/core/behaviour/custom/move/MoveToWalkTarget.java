package net.tslat.smartbrainlib.api.core.behaviour.custom.move;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.ai.NoPenaltyTargeting;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.WalkTarget;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtil;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class MoveToWalkTarget<E extends PathAwareEntity> extends ExtendedBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(3).hasMemory(MemoryModuleType.WALK_TARGET).noMemory(MemoryModuleType.PATH).usesMemory(MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE);

	@Nullable
	protected Path path;
	@Nullable
	protected BlockPos lastTargetPos;
	protected float speedModifier;

	public MoveToWalkTarget() {
		runFor(entity -> entity.getRandom().nextInt(100) + 150);
		cooldownFor(entity -> entity.getRandom().nextInt(40));
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean checkExtraStartConditions(ServerWorld level, E entity) {
		Brain<?> brain = entity.getBrain();
		WalkTarget walkTarget = BrainUtil.getMemory(brain, MemoryModuleType.WALK_TARGET);

		if (!hasReachedTarget(entity, walkTarget) && attemptNewPath(entity, walkTarget, false)) {
			this.lastTargetPos = walkTarget.getLookTarget().getBlockPos();

			return true;
		}

		BrainUtil.clearMemory(brain, MemoryModuleType.WALK_TARGET);
		BrainUtil.clearMemory(brain, MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE);

		return false;
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		if (this.path == null || this.lastTargetPos == null)
			return false;

		if (entity.getNavigation().isIdle())
			return false;

		WalkTarget walkTarget = BrainUtil.getMemory(entity, MemoryModuleType.WALK_TARGET);

		return walkTarget != null && !hasReachedTarget(entity, walkTarget);
	}

	@Override
	protected void start(E entity) {
		startOnNewPath(entity);
	}

	@Override
	protected void tick(E entity) {
		Path path = entity.getNavigation().getCurrentPath();
		Brain<?> brain = entity.getBrain();

		if (this.path != path) {
			this.path = path;

			BrainUtil.setMemory(brain, MemoryModuleType.PATH, path);
		}

		if (path != null && this.lastTargetPos != null) {
			WalkTarget walkTarget = BrainUtil.getMemory(brain, MemoryModuleType.WALK_TARGET);

			if (walkTarget.getLookTarget().getBlockPos().getSquaredDistance(this.lastTargetPos) > 4 && attemptNewPath(entity, walkTarget, hasReachedTarget(entity, walkTarget))) {
				this.lastTargetPos = walkTarget.getLookTarget().getBlockPos();

				startOnNewPath(entity);
			}
		}
	}

	@Override
	protected void stop(E entity) {
		Brain<?> brain = entity.getBrain();

		if (!entity.getNavigation().isNearPathStartPos() || !BrainUtil.hasMemory(brain, MemoryModuleType.WALK_TARGET) || hasReachedTarget(entity, BrainUtil.getMemory(brain, MemoryModuleType.WALK_TARGET)))
			this.cooldownFinishedAt = 0;

		entity.getNavigation().stop();
		BrainUtil.clearMemories(brain, MemoryModuleType.WALK_TARGET, MemoryModuleType.PATH);

		this.path = null;
	}

	protected boolean attemptNewPath(E entity, WalkTarget walkTarget, boolean reachedCurrentTarget) {
		Brain<?> brain = entity.getBrain();
		BlockPos pos = walkTarget.getLookTarget().getBlockPos();
		this.path = entity.getNavigation().findPathTo(pos, 0);
		this.speedModifier = walkTarget.getSpeed();

		if (reachedCurrentTarget) {
			BrainUtil.clearMemory(brain, MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE);

			return false;
		}

		if (this.path != null && this.path.reachesTarget()) {
			BrainUtil.clearMemory(brain, MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE);
		}
		else {
			BrainUtil.setMemory(brain, MemoryModuleType.CANT_REACH_WALK_TARGET_SINCE, entity.getWorld().getTime());
		}

		if (this.path != null)
			return true;

		Vec3d newTargetPos = NoPenaltyTargeting.findTo(entity, 10, 7, Vec3d.ofBottomCenter(pos), MathHelper.HALF_PI);

		if (newTargetPos != null) {
			this.path = entity.getNavigation().findPathTo(newTargetPos.getX(), newTargetPos.getY(), newTargetPos.getZ(), 0);

			return this.path != null;
		}

		return false;
	}

	protected boolean hasReachedTarget(E entity, WalkTarget target) {
		return target.getLookTarget().getBlockPos().getManhattanDistance(entity.getBlockPos()) <= target.getCompletionRange();
	}

	protected void startOnNewPath(E entity) {
		BrainUtil.setMemory(entity, MemoryModuleType.PATH, this.path);
		entity.getNavigation().startMovingAlong(this.path, this.speedModifier);
	}
}
