package net.tslat.smartbrainlib.registry;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import net.minecraft.block.BlockState;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.tslat.smartbrainlib.SBLConstants;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Registry class for custom {@link MemoryModuleType Memory Types}
 */
public final class SBLMemoryTypes {
	public static void init() {}

	public static final Supplier<MemoryModuleType<List<ProjectileEntity>>> INCOMING_PROJECTILES = register("incoming_projectiles");
	public static final Supplier<MemoryModuleType<Boolean>> TARGET_UNREACHABLE = register("target_unreachable");
	public static final Supplier<MemoryModuleType<Boolean>> SPECIAL_ATTACK_COOLDOWN = register("special_attack_cooldown");
	public static final Supplier<MemoryModuleType<List<Pair<BlockPos, BlockState>>>> NEARBY_BLOCKS = register("nearby_blocks");
	public static final Supplier<MemoryModuleType<List<ItemEntity>>> NEARBY_ITEMS = register("nearby_items");

	private static <T> Supplier<MemoryModuleType<T>> register(String id) {
		return register(id, Optional.empty());
	}

	private static <T> Supplier<MemoryModuleType<T>> register(String id, Optional<Codec<T>> codec) {
		return SBLConstants.SBL_LOADER.registerMemoryType(id, codec);
	}
}
