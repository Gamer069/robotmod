package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.LivingTargetCache;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.passive.PassiveEntity;
import net.tslat.smartbrainlib.api.core.sensor.EntityFilteringSensor;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiPredicate;

/**
 * A sensor that sets the {@link MemoryModuleType#NEAREST_VISIBLE_ADULT} memory
 * by checking the existing visible entities for nearby adults of the same
 * entity type. <br>
 * 
 * @see net.minecraft.entity.ai.brain.sensor.NearestVisibleAdultSensor
 * @param <E> The entity
 */
public class NearbyAdultSensor<E extends PassiveEntity> extends EntityFilteringSensor<PassiveEntity, E> {
	@Override
	public MemoryModuleType<PassiveEntity> getMemory() {
		return MemoryModuleType.NEAREST_VISIBLE_ADULT;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.NEARBY_ADULT.get();
	}

	@Override
	protected BiPredicate<LivingEntity, E> predicate() {
		return (target, entity) -> target.getType() == entity.getType() && !target.isBaby();
	}

	@Nullable
	@Override
	protected PassiveEntity findMatches(E entity, LivingTargetCache matcher) {
		return (PassiveEntity) matcher.findFirst(target -> predicate().test(target, entity)).orElse(null);
	}
}
