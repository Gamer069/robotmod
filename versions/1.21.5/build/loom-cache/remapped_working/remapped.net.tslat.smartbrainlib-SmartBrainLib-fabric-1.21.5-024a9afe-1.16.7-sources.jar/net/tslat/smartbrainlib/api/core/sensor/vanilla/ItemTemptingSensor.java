package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.api.core.sensor.PredicateSensor;
import net.tslat.smartbrainlib.object.SquareRadius;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;
import net.tslat.smartbrainlib.util.EntityRetrievalUtil;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.BiPredicate;

/**
 * Find the nearest player that is holding out a tempting item for the entity.
 * Defaults:
 * <ul>
 * <li>10x10x10 Radius</li>
 * <li>No spectators</li>
 * </ul>
 * 
 * @see net.minecraft.entity.ai.brain.sensor.TemptationsSensor
 * @param <E> The entity
 */
public class ItemTemptingSensor<E extends LivingEntity> extends PredicateSensor<PlayerEntity, E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(MemoryModuleType.TEMPTING_PLAYER);

	protected BiPredicate<E, ItemStack> temptPredicate = (entity, stack) -> false;
	protected SquareRadius radius = new SquareRadius(10, 10);

	public ItemTemptingSensor() {
		setPredicate((target, entity) -> {
			if (target.isSpectator() || !target.isAlive())
				return false;

			return this.temptPredicate.test(entity, target.getMainHandStack()) || this.temptPredicate.test(entity, target.getOffHandStack());
		});
	}

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.ITEM_TEMPTING.get();
	}

	/**
	 * Set the items to temptable items for the entity.
	 *
	 * @param predicate An ingredient representing the temptations for the
	 *                      entity
	 * @return this
	 */
	public ItemTemptingSensor<E> temptedWith(final BiPredicate<E, ItemStack> predicate) {
		this.temptPredicate = predicate;

		return this;
	}

	/**
	 * Set the radius for the player sensor to scan
	 * 
	 * @param radius The coordinate radius, in blocks
	 * @return this
	 */
	public ItemTemptingSensor<E> setRadius(double radius) {
		return setRadius(radius, radius);
	}

	/**
	 * Set the radius for the player sensor to scan.
	 * 
	 * @param xz The X/Z coordinate radius, in blocks
	 * @param y  The Y coordinate radius, in blocks
	 * @return this
	 */
	public ItemTemptingSensor<E> setRadius(double xz, double y) {
		this.radius = new SquareRadius(xz, y);

		return this;
	}

	@Override
	protected void sense(ServerWorld level, E entity) {
		Optional<PlayerEntity> player;
		final List<PlayerEntity> nearbyPlayers = BrainUtil.getMemory(entity, MemoryModuleType.NEAREST_PLAYERS);

		if (nearbyPlayers != null) {
			player = nearbyPlayers.stream().filter(pl -> predicate().test(pl, entity)).min(Comparator.comparing(pl -> pl.squaredDistanceTo(entity)));
		}
		else {
			player = EntityRetrievalUtil.getNearestPlayer(entity, this.radius.xzRadius(), this.radius.yRadius(), this.radius.xzRadius(), target -> predicate().test(target, entity));
		}

		player.ifPresentOrElse(pl ->
				BrainUtil.setMemory(entity, MemoryModuleType.TEMPTING_PLAYER, pl),
				() -> BrainUtil.clearMemory(entity, MemoryModuleType.TEMPTING_PLAYER));
	}
}
