package net.tslat.smartbrainlib.api.core.behaviour.custom.misc;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.task.TargetUtil;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.object.MemoryTest;
import net.tslat.smartbrainlib.object.ToFloatBiFunction;
import net.tslat.smartbrainlib.util.BrainUtil;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.ToIntBiFunction;

/**
 * Functional replacement for vanilla's {@link net.minecraft.entity.ai.brain.task.BreedTask AnimalMakeLove}.
 * <p>Makes the entity find, move to, and breed with its target mate, producing offspring.</p>
 * Defaults:
 * <ul>
 *     <li>1x walk speed modifier when moving to its breeding partner</li>
 *     <li>Spend between 3 and 5.5 seconds to create the offspring</li>
 * </ul>
 */
public class BreedWithPartner<E extends AnimalEntity> extends ExtendedBehaviour<E> {
	private static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(4).hasMemory(MemoryModuleType.VISIBLE_MOBS).noMemory(MemoryModuleType.BREED_TARGET).usesMemories(MemoryModuleType.LOOK_TARGET, MemoryModuleType.WALK_TARGET);

	protected ToFloatBiFunction<E, AnimalEntity> speedMod = (entity, partner) -> 1f;
	protected ToIntBiFunction<E, AnimalEntity> closeEnoughDist = (entity, partner) -> 2;
	protected ToIntBiFunction<E, AnimalEntity> breedTime = (entity, partner) -> entity.getRandom().nextBetweenExclusive(60, 110);
	protected BiPredicate<E, AnimalEntity> partnerPredicate = (entity, partner) -> entity.getType() == partner.getType() && entity.canBreedWith(partner);

	protected int childBreedTick = -1;
	protected AnimalEntity partner = null;

	public BreedWithPartner() {
		noTimeout();
	}

	/**
	 * Set the movespeed modifier for the entity when moving to their partner.
	 * @param speedModifier The movespeed modifier/multiplier
	 * @return this
	 */
	public BreedWithPartner<E> speedMod(final ToFloatBiFunction<E, AnimalEntity> speedModifier) {
		this.speedMod = speedModifier;

		return this;
	}

	/**
	 * Sets the amount (in blocks) that the animal can be considered 'close enough' to their partner that they can stop pathfinding
	 * @param closeEnoughDist The distance function
	 * @return this
	 */
	public BreedWithPartner<E> closeEnoughDist(final ToIntBiFunction<E, AnimalEntity> closeEnoughDist) {
		this.closeEnoughDist = closeEnoughDist;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}

	@Override
	protected boolean checkExtraStartConditions(ServerWorld level, E entity) {
		if (!entity.isInLove())
			return false;

		this.partner = findPartner(entity);

		return this.partner != null;
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		return this.partner != null && this.partner.isAlive() && entity.age <= this.childBreedTick && TargetUtil.canSee(entity.getBrain(), this.partner) && this.partnerPredicate.test(entity, this.partner);
	}

	@Override
	protected void start(E entity) {
		this.childBreedTick = entity.age + this.breedTime.applyAsInt(entity, this.partner);

		BrainUtil.setMemory(entity, MemoryModuleType.BREED_TARGET, this.partner);
		BrainUtil.setMemory(this.partner, MemoryModuleType.BREED_TARGET, entity);
		TargetUtil.lookAtAndWalkTowardsEachOther(entity, this.partner, this.speedMod.applyAsFloat(entity, this.partner), this.closeEnoughDist.applyAsInt(entity, this.partner));
	}

	@Override
	protected void tick(E entity) {
		TargetUtil.lookAtAndWalkTowardsEachOther(entity, this.partner, this.speedMod.applyAsFloat(entity, this.partner), this.closeEnoughDist.applyAsInt(entity, this.partner));

		if (entity.isInRange(this.partner, 3) && entity.age == this.childBreedTick) {
			entity.breed((ServerWorld)entity.getWorld(), this.partner);
			BrainUtil.clearMemory(entity, MemoryModuleType.BREED_TARGET);
			BrainUtil.clearMemory(this.partner, MemoryModuleType.BREED_TARGET);
		}
	}

	@Override
	protected void stop(E entity) {
		BrainUtil.clearMemories(entity, MemoryModuleType.BREED_TARGET, MemoryModuleType.LOOK_TARGET, MemoryModuleType.WALK_TARGET);

		if (this.partner != null)
			BrainUtil.clearMemories(this.partner, MemoryModuleType.BREED_TARGET, MemoryModuleType.LOOK_TARGET, MemoryModuleType.WALK_TARGET);

		this.childBreedTick = -1;
		this.partner = null;
	}

	@Nullable
	protected AnimalEntity findPartner(E entity) {
		return BrainUtil.getMemory(entity, MemoryModuleType.VISIBLE_MOBS).findFirst(entity2 -> entity2 instanceof AnimalEntity partner && this.partnerPredicate.test(entity, partner)).map(AnimalEntity.class::cast).orElse(null);
	}
}
