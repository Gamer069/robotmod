package net.tslat.smartbrainlib.api.core.behaviour.custom.path;

import org.jetbrains.annotations.Nullable;

import java.util.function.ToIntFunction;
import net.minecraft.entity.ai.AboveGroundTargeting;
import net.minecraft.entity.ai.NoPenaltySolidTargeting;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Extension of {@link SetRandomHoverTarget}, with a configurable weight to allow for more 'flying'-like movement
 * <p>Additionally expands the vertical path search radius to 10, over the default of 7</p>
 */
public class SetRandomFlyingTarget<E extends PathAwareEntity> extends SetRandomHoverTarget<E> {
    protected ToIntFunction<E> verticalWeight = entity -> -2;

    public SetRandomFlyingTarget() {
        setRadius(10, 10);
    }

    /**
     * Sets the function that determines a vertical position offset for target positions.<br>
     * Flight patterns will tend towards this direction, with bigger values pulling more strongly
     * @param function The function
     * @return this
     */
    public SetRandomFlyingTarget<E> verticalWeight(ToIntFunction<E> function) {
        this.verticalWeight = function;

        return this;
    }

    @Nullable
    @Override
    protected Vec3d getTargetPos(E entity) {
        Vec3d entityFacing = entity.getRotationVec(0);
        Vec3d hoverPos = AboveGroundTargeting.find(entity, (int)(Math.ceil(this.radius.xzRadius())), (int)Math.ceil(this.radius.yRadius()), entityFacing.x, entityFacing.z, MathHelper.HALF_PI, 3, 1);

        if (hoverPos != null)
            return hoverPos;

        return NoPenaltySolidTargeting.find(entity, (int)(Math.ceil(this.radius.xzRadius())), (int)Math.ceil(this.radius.yRadius()), this.verticalWeight.applyAsInt(entity), entityFacing.x, entityFacing.z, MathHelper.HALF_PI);
    }
}
