package net.tslat.smartbrainlib.api.core.navigation;

import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.BirdPathNodeMaker;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.ai.pathing.PathNodeNavigator;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Extension of the vanilla {@link BirdNavigation} with some tweaks for smoother pathfinding:
 * <ul>
 *     <li>Patched {@link Path} implementation to use proper rounding</li>
 * </ul>
 * <p>
 * Override {@link MobEntity#createNavigation(World)} and return a new instance of this if your entity is a ground-based walking entity
 */
public class SmoothFlyingPathNavigation extends BirdNavigation implements ExtendedNavigator {
    public SmoothFlyingPathNavigation(MobEntity mob, World level) {
        super(mob, level);
    }

    @Override
    public MobEntity getMob() {
        return this.entity;
    }

    @Nullable
    @Override
    public Path getCurrentPath() {
        return super.getCurrentPath();
    }

    /**
     * Patch {@link Path#getNodePosition} to use a proper rounding check
     */
    @Override
    protected PathNodeNavigator createPathNodeNavigator(int maxVisitedNodes) {
        this.nodeMaker = new BirdPathNodeMaker();
        this.nodeMaker.setCanEnterOpenDoors(true);

        return createSmoothPathFinder(this.nodeMaker, maxVisitedNodes);
    }
}
