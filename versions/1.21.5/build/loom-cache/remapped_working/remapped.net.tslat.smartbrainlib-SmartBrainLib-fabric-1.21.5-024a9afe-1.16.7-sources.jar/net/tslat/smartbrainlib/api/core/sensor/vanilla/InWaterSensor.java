package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Unit;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.api.core.sensor.PredicateSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;

import java.util.List;

/**
 * A sensor that sets or clears the {@link MemoryModuleType#IS_IN_WATER} memory
 * depending on certain criteria. <br>
 * Defaults:
 * <ul>
 * <li>{@link LivingEntity#isTouchingWater()}</li>
 * </ul>
 * 
 * @param <E> The entity
 */
public class InWaterSensor<E extends LivingEntity> extends PredicateSensor<E, E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(MemoryModuleType.IS_IN_WATER);

	public InWaterSensor() {
		super((entity2, entity) -> entity.isTouchingWater());
	}

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.IN_WATER.get();
	}

	@Override
	protected void sense(ServerWorld level, E entity) {
		if (predicate().test(entity, entity)) {
			BrainUtil.setMemory(entity, MemoryModuleType.IS_IN_WATER, Unit.INSTANCE);
		}
		else {
			BrainUtil.clearMemory(entity, MemoryModuleType.IS_IN_WATER);
		}
	}
}
