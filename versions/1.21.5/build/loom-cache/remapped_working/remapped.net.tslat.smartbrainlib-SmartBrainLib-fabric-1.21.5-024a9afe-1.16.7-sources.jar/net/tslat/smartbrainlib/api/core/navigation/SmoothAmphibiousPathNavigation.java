package net.tslat.smartbrainlib.api.core.navigation;

import net.minecraft.entity.ai.pathing.AmphibiousPathNodeMaker;
import net.minecraft.entity.ai.pathing.AmphibiousSwimNavigation;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.ai.pathing.PathNodeNavigator;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Extension of the vanilla {@link AmphibiousSwimNavigation} with some tweaks for smoother pathfinding:
 * <ul>
 *     <li>Patched {@link Path} implementation to use proper rounding</li>
 *     <li>Extensible {@link #prefersShallowSwimming()} implementation for ease-of-use</li>
 * </ul>
 * <p>
 * Override {@link MobEntity#createNavigation(World)} and return a new instance of this if your entity is a ground-based walking entity
 */
public class SmoothAmphibiousPathNavigation extends AmphibiousSwimNavigation implements ExtendedNavigator {
    public SmoothAmphibiousPathNavigation(MobEntity mob, World level) {
        super(mob, level);
    }

    /**
     * Determine whether the navigator should prefer shallow swimming patterns
     * <p>
     * Adjusts path node penalty when determining paths
     */
    public boolean prefersShallowSwimming() {
        return false;
    }

    @Override
    public MobEntity getMob() {
        return this.entity;
    }

    @Nullable
    @Override
    public Path getCurrentPath() {
        return super.getCurrentPath();
    }

    /**
     * Patch {@link Path#getNodePosition} to use a proper rounding check
     */
    @Override
    protected PathNodeNavigator createPathNodeNavigator(int maxVisitedNodes) {
        this.nodeMaker = new AmphibiousPathNodeMaker(prefersShallowSwimming());
        this.nodeMaker.setCanEnterOpenDoors(true);

        return createSmoothPathFinder(this.nodeMaker, maxVisitedNodes);
    }
}
