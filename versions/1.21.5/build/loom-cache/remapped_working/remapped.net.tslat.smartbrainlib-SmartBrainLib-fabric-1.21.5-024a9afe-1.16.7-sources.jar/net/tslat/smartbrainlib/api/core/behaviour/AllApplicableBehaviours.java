package net.tslat.smartbrainlib.api.core.behaviour;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.task.Task;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.object.SBLShufflingList;
import org.jetbrains.annotations.Nullable;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * Group behaviour that attempts to run all sub-behaviours in order, running any that apply.<br>
 * This allows for wrapping entire groups of behaviours in overarching conditions or nesting them in other groups.<br>
 * This will count this behaviour as running if any of the child behaviours are running.
 * @param <E> The entity
 */
public final class AllApplicableBehaviours<E extends LivingEntity> extends GroupBehaviour<E> {
	public AllApplicableBehaviours(Pair<ExtendedBehaviour<? super E>, Integer>... behaviours) {
		super(behaviours);
	}

	public AllApplicableBehaviours(ExtendedBehaviour<? super E>... behaviours) {
		super(behaviours);
	}

	@Nullable
	@Override
	protected ExtendedBehaviour<? super E> pickBehaviour(ServerWorld level, E entity, long gameTime, SBLShufflingList<ExtendedBehaviour<? super E>> extendedBehaviours) {
		ExtendedBehaviour<? super E> lastSuccessfulBehaviour = null;

		for (ExtendedBehaviour<? super E> behaviour : extendedBehaviours) {
			if (behaviour.tryStarting(level, entity, gameTime))
				lastSuccessfulBehaviour = behaviour;
		}

		return lastSuccessfulBehaviour;
	}

	@Override
	protected boolean shouldKeepRunning(E entity) {
		boolean stillOperational = false;

		for (ExtendedBehaviour<? super E> behaviour : this.behaviours) {
			stillOperational |= behaviour.getStatus() == Status.RUNNING && behaviour.shouldKeepRunning((ServerWorld)entity.getWorld(), entity, entity.getWorld().getTime());
		}

		return stillOperational;
	}

	@Override
	protected boolean isTimeLimitExceeded(long gameTime) {
		boolean timedOut = true;

		for (ExtendedBehaviour<? super E> behaviour : this.behaviours) {
			if (behaviour.getStatus() == Status.RUNNING && !behaviour.isTimeLimitExceeded(gameTime))
				timedOut = false;
		}

		return timedOut;
	}

	@Override
	protected void keepRunning(ServerWorld level, E owner, long gameTime) {
		boolean stillRunning = false;

		for (ExtendedBehaviour<? super E> behaviour : this.behaviours) {
			if (behaviour.getStatus() == Status.RUNNING) {
				behaviour.tick(level, owner, gameTime);

				if (behaviour.getStatus() != Status.STOPPED)
					stillRunning = true;
			}
		}

		if (!stillRunning)
			stop(level, owner, gameTime);
	}

	@Override
	protected void finishRunning(ServerWorld level, E entity, long gameTime) {
		this.cooldownFinishedAt = gameTime + this.cooldownProvider.applyAsInt(entity);

		this.taskStopCallback.accept(entity);
		stop(entity);

		for (ExtendedBehaviour<? super E> behaviour : this.behaviours) {
			if (behaviour.getStatus() == Status.RUNNING)
				behaviour.stop(level, entity, gameTime);
		}
	}

	@Override
	public Status getStatus() {
		for (ExtendedBehaviour<? super E> behaviour : this.behaviours) {
			if (behaviour.getStatus() == Status.RUNNING)
				return Status.RUNNING;
		}

		return Status.STOPPED;
	}

	@Override
	public String toString() {
		final Set<? extends Task<? super E>> activeBehaviours = this.behaviours.stream()
				.filter(behaviorControl -> behaviorControl.getStatus() == Status.RUNNING)
				.collect(Collectors.toSet());

		return "(" + getClass().getSimpleName() + "): " + activeBehaviours;
	}
}
