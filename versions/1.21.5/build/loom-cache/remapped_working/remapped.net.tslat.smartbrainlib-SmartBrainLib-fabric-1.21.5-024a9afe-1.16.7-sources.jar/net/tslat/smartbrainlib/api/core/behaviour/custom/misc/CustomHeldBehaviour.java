package net.tslat.smartbrainlib.api.core.behaviour.custom.misc;

import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleState;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.tslat.smartbrainlib.api.core.behaviour.ExtendedBehaviour;
import net.tslat.smartbrainlib.api.core.behaviour.HeldBehaviour;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * A behaviour module that invokes a callback every tick until stopped.<br>
 * Useful for handling custom minor actions that are either too specific to warrant a new behaviour, or not worth implementing into a full behaviour.<br>
 * Set the condition for running via {@link ExtendedBehaviour#startCondition(Predicate)}<br>
 * Set the condition for stopping via {@link ExtendedBehaviour#stopIf(Predicate)}
 */
public final class CustomHeldBehaviour<E extends LivingEntity> extends HeldBehaviour<E> {
	private Consumer<E> callback;

	public CustomHeldBehaviour(Consumer<E> callback) {
		this.callback = callback;
	}

	/**
	 * Replace the callback function
	 * @return this
	 */
	public CustomHeldBehaviour<E> callback(Consumer<E> callback) {
		this.callback = callback;

		return this;
	}

	@Override
	protected List<Pair<MemoryModuleType<?>, MemoryModuleState>> getMemoryRequirements() {
		return List.of();
	}

	@Override
	protected void tick(E entity) {
		this.callback.accept(entity);
	}
}
