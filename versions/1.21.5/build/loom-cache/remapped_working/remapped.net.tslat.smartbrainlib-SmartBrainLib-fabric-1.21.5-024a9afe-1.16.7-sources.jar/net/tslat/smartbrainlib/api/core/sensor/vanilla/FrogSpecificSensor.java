package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.LivingTargetCache;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.Sensor;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.passive.FrogEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.sensor.EntityFilteringSensor;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;
import java.util.function.BiPredicate;

/**
 * A replication of vanilla's
 * {@link net.minecraft.entity.ai.brain.sensor.FrogAttackablesSensor}. Not
 * really useful, but included for completeness' sake and legibility. <br>
 * Handles the Frog's tongue target.
 * 
 * @param <E> The entity
 */
public class FrogSpecificSensor<E extends LivingEntity> extends EntityFilteringSensor<LivingEntity, E> {
	@Override
	public MemoryModuleType<LivingEntity> getMemory() {
		return MemoryModuleType.NEAREST_ATTACKABLE;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.FROG_SPECIFIC.get();
	}

	@Override
	protected BiPredicate<LivingEntity, E> predicate() {
		return (target, entity) -> {
			if (BrainUtil.hasMemory(entity, MemoryModuleType.HAS_HUNTING_COOLDOWN))
				return false;

			if (!Sensor.testAttackableTargetPredicate((ServerWorld)entity.getWorld(), entity, target))
				return false;

			if (!FrogEntity.isValidFrogFood(target))
				return false;

			if (!target.isInRange(entity, 10))
				return false;

			List<UUID> unreachableTargets = BrainUtil.getMemory(entity, MemoryModuleType.UNREACHABLE_TONGUE_TARGETS);

			return unreachableTargets == null || !unreachableTargets.contains(target.getUuid());
		};
	}

	@Nullable
	@Override
	protected LivingEntity findMatches(E entity, LivingTargetCache matcher) {
		return matcher.findFirst(target -> predicate().test(target, entity)).orElse(null);
	}
}
