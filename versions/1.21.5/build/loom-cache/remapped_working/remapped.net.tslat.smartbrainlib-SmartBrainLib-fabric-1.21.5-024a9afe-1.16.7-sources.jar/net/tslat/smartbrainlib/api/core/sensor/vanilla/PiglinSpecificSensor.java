package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.AbstractPiglinEntity;
import net.minecraft.entity.mob.HoglinEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PiglinBrain;
import net.minecraft.entity.mob.PiglinBruteEntity;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;

import java.util.List;

/**
 * A replication of vanilla's
 * {@link net.minecraft.entity.ai.brain.sensor.PiglinSpecificSensor}. Not
 * really useful, but included for completeness' sake and legibility. <br>
 * Handles most of Piglin's memories at once.
 * 
 * @param <E> The entity
 */
public class PiglinSpecificSensor<E extends LivingEntity> extends ExtendedSensor<E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(MemoryModuleType.NEAREST_VISIBLE_NEMESIS, MemoryModuleType.NEAREST_VISIBLE_HUNTABLE_HOGLIN, MemoryModuleType.NEAREST_VISIBLE_BABY_HOGLIN, MemoryModuleType.NEAREST_VISIBLE_ZOMBIFIED, MemoryModuleType.NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD, MemoryModuleType.NEAREST_PLAYER_HOLDING_WANTED_ITEM, MemoryModuleType.NEAREST_VISIBLE_ADULT_PIGLINS, MemoryModuleType.VISIBLE_ADULT_PIGLIN_COUNT, MemoryModuleType.VISIBLE_ADULT_HOGLIN_COUNT, MemoryModuleType.NEAREST_REPELLENT, MemoryModuleType.MOBS, MemoryModuleType.NEARBY_ADULT_PIGLINS);

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.PIGLIN_SPECIFIC.get();
	}

	@Override
	protected void sense(ServerWorld level, E entity) {
		Brain<?> brain = entity.getBrain();
		List<AbstractPiglinEntity> adultPiglins = new ObjectArrayList<>();

		BrainUtil.withMemory(brain, MemoryModuleType.VISIBLE_MOBS, entities -> {
			MobEntity nemesis = null;
			HoglinEntity nearestHuntableHoglin = null;
			HoglinEntity nearestBabyHoglin = null;
			LivingEntity nearestZombified = null;
			PlayerEntity nearestPlayerWithoutGold = null;
			PlayerEntity nearestPlayerWithWantedItem = null;
			List<AbstractPiglinEntity> visibleAdultPiglins = new ObjectArrayList<>();
			int adultHoglinCount = 0;

			for (LivingEntity target : entities.iterate(obj -> true)) {
				if (target instanceof HoglinEntity hoglin) {
					if (hoglin.isBaby() && nearestBabyHoglin == null) {
						nearestBabyHoglin = hoglin;
					}
					else if (hoglin.isAdult()) {
						adultHoglinCount++;

						if (nearestHuntableHoglin == null && hoglin.canBeHunted())
							nearestHuntableHoglin = hoglin;
					}
				}
				else if (target instanceof PiglinBruteEntity brute) {
					visibleAdultPiglins.add(brute);
				}
				else if (target instanceof PiglinEntity piglin) {
					if (piglin.isAdult())
						visibleAdultPiglins.add(piglin);
				}
				else if (target instanceof PlayerEntity player) {
					if (nearestPlayerWithoutGold == null && !PiglinBrain.isWearingPiglinSafeArmor(player) && entity.canTarget(player))
						nearestPlayerWithoutGold = player;

					if (nearestPlayerWithWantedItem == null && !player.isSpectator() && PiglinBrain.isGoldHoldingPlayer(player))
						nearestPlayerWithWantedItem = player;
				}
				else if (nemesis != null || !(target instanceof WitherSkeletonEntity) && !(target instanceof WitherEntity)) {
					if (nearestZombified == null && PiglinBrain.isZombified(target.getType()))
						nearestZombified = target;
				}
				else {
					nemesis = (MobEntity) target;
				}
			}

			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_NEMESIS, nemesis);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_HUNTABLE_HOGLIN, nearestHuntableHoglin);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_BABY_HOGLIN, nearestBabyHoglin);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_ZOMBIFIED, nearestZombified);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD, nearestPlayerWithoutGold);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_PLAYER_HOLDING_WANTED_ITEM, nearestPlayerWithWantedItem);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_ADULT_PIGLINS, visibleAdultPiglins);
			BrainUtil.setMemory(brain, MemoryModuleType.VISIBLE_ADULT_PIGLIN_COUNT, visibleAdultPiglins.size());
			BrainUtil.setMemory(brain, MemoryModuleType.VISIBLE_ADULT_HOGLIN_COUNT, adultHoglinCount);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_REPELLENT,
					BlockPos.findClosest(entity.getBlockPos(), 8, 4, pos -> {
						BlockState state = level.getBlockState(pos);
						boolean isRepellent = state.isIn(BlockTags.PIGLIN_REPELLENTS);

						return isRepellent && state.isOf(Blocks.SOUL_CAMPFIRE) ? CampfireBlock.isLitCampfire(state) : isRepellent;
					}).orElse(null));
		});

		BrainUtil.withMemory(brain, MemoryModuleType.MOBS, entities -> {
			for (LivingEntity target : entities) {
				if (target instanceof AbstractPiglinEntity piglin && piglin.isAdult())
					adultPiglins.add(piglin);
			}
		});
		BrainUtil.setMemory(brain, MemoryModuleType.NEARBY_ADULT_PIGLINS, adultPiglins);
	}
}
