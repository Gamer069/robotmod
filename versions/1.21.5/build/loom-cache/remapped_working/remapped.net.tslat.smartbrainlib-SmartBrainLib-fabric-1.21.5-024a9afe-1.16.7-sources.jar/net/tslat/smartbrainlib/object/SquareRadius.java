package net.tslat.smartbrainlib.object;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

/**
 * Helper class to store radius values without needlessly using 3 values. <br>
 * Also comes with some handy helper methods.
 * @param xzRadius The lateral radius value (X/Z direction)
 * @param yRadius The vertical radius value (Y direction)
 */
public record SquareRadius(double xzRadius, double yRadius) {
	public Vec3i toVec3i() {
		return new Vec3i((int)this.xzRadius, (int)this.yRadius, (int)this.xzRadius);
	}

	public BlockPos toBlockPos() {
		return BlockPos.ofFloored(this.xzRadius, this.yRadius, this.xzRadius);
	}

	public Vec3d toVec3() {
		return new Vec3d(this.xzRadius, this.yRadius, this.xzRadius);
	}

	public Box inflateAABB(Box bounds) {
		return bounds.expand(this.xzRadius, this.yRadius, this.xzRadius);
	}
}