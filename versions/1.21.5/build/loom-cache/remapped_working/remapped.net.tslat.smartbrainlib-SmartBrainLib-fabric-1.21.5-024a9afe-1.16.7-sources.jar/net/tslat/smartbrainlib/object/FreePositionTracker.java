package net.tslat.smartbrainlib.object;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.LookTarget;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * PositionTracker implementation that takes a raw {@link Vec3d} for precision
 */
public class FreePositionTracker implements LookTarget {
	private final Vec3d pos;

	public FreePositionTracker(Vec3d pos) {
		this.pos = pos;
	}

	@Override
	public Vec3d getPos() {
		return this.pos;
	}

	@Override
	public BlockPos getBlockPos() {
		return BlockPos.ofFloored(this.pos);
	}

	@Override
	public boolean isSeenBy(LivingEntity entity) {
		return true;
	}

	@Override
	public String toString() {
		return "FreePositionTracker{pos=" + this.pos + "}";
	}
}
