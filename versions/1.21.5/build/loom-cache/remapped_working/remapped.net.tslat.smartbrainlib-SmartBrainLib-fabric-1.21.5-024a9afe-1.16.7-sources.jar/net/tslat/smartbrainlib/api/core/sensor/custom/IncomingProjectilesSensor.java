package net.tslat.smartbrainlib.api.core.sensor.custom;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.server.world.ServerWorld;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.api.core.sensor.PredicateSensor;
import net.tslat.smartbrainlib.registry.SBLMemoryTypes;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;
import net.tslat.smartbrainlib.util.EntityRetrievalUtil;

import java.util.Comparator;
import java.util.List;

/**
 * Custom sensor that detects incoming projectiles.
 * Defaults:
 * <ul>
 *     <li>3-tick scan rate</li>
 *     <li>Only projectiles that are still in flight</li>
 *     <li>Only projectiles that will hit the entity before the next scan</li>
 * </ul>
 * @param <E>
 */
public class IncomingProjectilesSensor<E extends LivingEntity> extends PredicateSensor<ProjectileEntity, E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(SBLMemoryTypes.INCOMING_PROJECTILES.get());

	public IncomingProjectilesSensor() {
		setScanRate(entity -> 3);
		setPredicate((projectile, entity) -> {
			if (projectile.isOnGround() || projectile.horizontalCollision || projectile.verticalCollision)
				return false;

			return entity.getBoundingBox().raycast(projectile.getPos(), projectile.getPos().add(projectile.getVelocity().multiply(3, 3, 3))).isPresent();
		});
	}

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.INCOMING_PROJECTILES.get();
	}

	@Override
	protected void sense(ServerWorld level, E entity) {
		List<ProjectileEntity> projectiles = EntityRetrievalUtil.getEntities(entity, 7, ProjectileEntity.class, projectile -> predicate().test(projectile, entity));

		if (!projectiles.isEmpty()) {
			projectiles.sort(Comparator.comparingDouble(entity::squaredDistanceTo));
			BrainUtil.setMemory(entity, SBLMemoryTypes.INCOMING_PROJECTILES.get(), projectiles);
		}
		else {
			BrainUtil.clearMemory(entity, SBLMemoryTypes.INCOMING_PROJECTILES.get());
		}
	}
}
