package net.tslat.smartbrainlib.api.core.sensor.vanilla;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.entity.mob.HoglinEntity;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import net.tslat.smartbrainlib.registry.SBLSensors;
import net.tslat.smartbrainlib.util.BrainUtil;

import java.util.List;

/**
 * A replication of vanilla's
 * {@link net.minecraft.entity.ai.brain.sensor.HoglinSpecificSensor}. Not
 * really useful, but included for completeness' sake and legibility. <br>
 * Handles most of Hoglin's memories at once
 * 
 * @param <E> The entity
 */
public class HoglinSpecificSensor<E extends LivingEntity> extends ExtendedSensor<E> {
	private static final List<MemoryModuleType<?>> MEMORIES = ObjectArrayList.of(
			MemoryModuleType.NEAREST_VISIBLE_ADULT_PIGLIN, MemoryModuleType.NEAREST_VISIBLE_ADULT_HOGLINS,
			MemoryModuleType.VISIBLE_ADULT_PIGLIN_COUNT, MemoryModuleType.VISIBLE_ADULT_HOGLIN_COUNT,
			MemoryModuleType.NEAREST_REPELLENT);

	@Override
	public List<MemoryModuleType<?>> memoriesUsed() {
		return MEMORIES;
	}

	@Override
	public SensorType<? extends ExtendedSensor<?>> type() {
		return SBLSensors.HOGLIN_SPECIFIC.get();
	}

	@Override
	protected void sense(ServerWorld level, E entity) {
		Brain<?> brain = entity.getBrain();

		BrainUtil.withMemory(brain, MemoryModuleType.VISIBLE_MOBS, entities -> {
			int piglinCount = 0;
			PiglinEntity nearestPiglin = null;
			List<HoglinEntity> hoglins = new ObjectArrayList<>();

			for (LivingEntity target : entities.iterate(mob -> !mob.isBaby())) {
				if (target instanceof PiglinEntity piglin) {
					piglinCount++;

					if (nearestPiglin == null)
						nearestPiglin = piglin;
				}
				else if (target instanceof HoglinEntity hoglin) {
					hoglins.add(hoglin);
				}
			}

			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_ADULT_PIGLIN, nearestPiglin);
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_VISIBLE_ADULT_HOGLINS, hoglins);
			BrainUtil.setMemory(brain, MemoryModuleType.VISIBLE_ADULT_PIGLIN_COUNT, piglinCount);
			BrainUtil.setMemory(brain, MemoryModuleType.VISIBLE_ADULT_HOGLIN_COUNT, hoglins.size());
			BrainUtil.setMemory(brain, MemoryModuleType.NEAREST_REPELLENT, BlockPos.findClosest(entity.getBlockPos(), 8, 4, pos -> level.getBlockState(pos).isIn(BlockTags.HOGLIN_REPELLENTS)).orElse(null));
		});
	}
}
