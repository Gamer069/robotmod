package net.tslat.smartbrainlib;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.sensor.SensorType;
import net.minecraft.world.World;
import net.tslat.smartbrainlib.api.core.sensor.ExtendedSensor;
import org.jetbrains.annotations.ApiStatus;

import java.util.Collection;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

public interface SBLLoader {
	void init(Object eventBus);
	boolean isDevEnv();
	Pair<Collection<? extends Entity>, Function<Entity, ? extends Entity>> getPartEntities(World level);

	@ApiStatus.Internal
	<T> Supplier<MemoryModuleType<T>> registerMemoryType(String id);
	@ApiStatus.Internal
	<T> Supplier<MemoryModuleType<T>> registerMemoryType(String id, Optional<Codec<T>> codec);
	@ApiStatus.Internal
	<T extends ExtendedSensor<?>> Supplier<SensorType<T>> registerSensorType(String id, Supplier<T> sensor);
}
