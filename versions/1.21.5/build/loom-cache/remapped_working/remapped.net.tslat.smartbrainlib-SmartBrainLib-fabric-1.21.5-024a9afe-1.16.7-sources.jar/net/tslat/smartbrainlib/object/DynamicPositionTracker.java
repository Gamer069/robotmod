package net.tslat.smartbrainlib.object;

import java.util.function.Supplier;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.LookTarget;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * PositionTracker implementation that takes a {@link Vec3d} supplier, allowing for dynamic positioning
 */
public class DynamicPositionTracker implements LookTarget {
	private final Supplier<Vec3d> posSupplier;

	public DynamicPositionTracker(Supplier<Vec3d> posSupplier) {
		this.posSupplier = posSupplier;
	}

	@Override
	public Vec3d getPos() {
		return this.posSupplier.get();
	}

	@Override
	public BlockPos getBlockPos() {
		return BlockPos.ofFloored(this.posSupplier.get());
	}

	@Override
	public boolean isSeenBy(LivingEntity entity) {
		return true;
	}
}
