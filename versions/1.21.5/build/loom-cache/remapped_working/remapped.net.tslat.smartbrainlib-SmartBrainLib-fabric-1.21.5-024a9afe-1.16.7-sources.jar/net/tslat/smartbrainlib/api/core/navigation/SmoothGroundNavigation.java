package net.tslat.smartbrainlib.api.core.navigation;

import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.ai.pathing.LandPathNodeMaker;
import net.minecraft.entity.ai.pathing.MobNavigation;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.ai.pathing.PathNodeNavigator;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Extension of the vanilla {@link MobNavigation} with some tweaks for smoother pathfinding:
 * <ul>
 *     <li>Smoothed unit rounding to better accommodate edge-cases</li>
 *     <li>Patched {@link Path} implementation to use proper rounding</li>
 *     <li>Skip to vertical traversal first before continuing path nodes if appropriate</li>
 *     <li>Accessible {@link MobNavigation#getPathfindingY()} override for extensibility</li>
 * </ul>
 * <p>
 * Override {@link MobEntity#createNavigation(World)} and return a new instance of this if your entity is a ground-based walking entity
 * @see ExtendedNavigator#canPathOnto
 * @see ExtendedNavigator#canPathInto
 */
public class SmoothGroundNavigation extends MobNavigation implements ExtendedNavigator {
    public SmoothGroundNavigation(MobEntity mob, World level) {
        super(mob, level);
    }

    @Override
    public MobEntity getMob() {
        return this.entity;
    }

    @Nullable
    @Override
    public Path getCurrentPath() {
        return super.getCurrentPath();
    }

    /**
     * Patch {@link Path#getNodePosition} to use a proper rounding check
     */
    @Override
    protected PathNodeNavigator createPathNodeNavigator(int maxVisitedNodes) {
        this.nodeMaker = new LandPathNodeMaker();
        this.nodeMaker.setCanEnterOpenDoors(true);

        return createSmoothPathFinder(this.nodeMaker, maxVisitedNodes);
    }

    @Override
    protected void continueFollowingPath() {
        final Vec3d safeSurfacePos = getPos();
        final int shortcutNode = getClosestVerticalTraversal(MathHelper.floor(safeSurfacePos.y));
        this.nodeReachProximity = this.entity.getWidth() > 0.75f ? this.entity.getWidth() / 2f : 0.75f - this.entity.getWidth() / 2f;

        if (!attemptShortcut(shortcutNode, safeSurfacePos)) {
            if (isCloseToNextNode(0.5f) || isAboutToTraverseVertically() && isCloseToNextNode(getNodeReachProximity()))
                this.currentPath.next();
        }

        checkTimeouts(safeSurfacePos);
    }

    /**
     * Helper override to allow end-users to modify the fluids an entity can swim in
     * <p>
     * If using this to modify swimmable fluids, ensure you also override {@link EntityNavigation#isAtValidPosition()} as well
     *
     * @return The nearest safe surface height for the entity
     */
    @Override
    public int getPathfindingY() {
        return super.getPathfindingY();
    }

    /**
     * Find the nearest node in the path that accounts for a vertical traversal (either up or down)
     * <p>
     * This can then be used to test if a collision-free traversal can be made, skipping the intermediate nodes as appropriate
     *
     * @param safeSurfaceHeight The baseline floored y-pos of where the mob should traverse to (usually the nearest ground pos or surface of the fluid it's submerged in)
     *
     * @return The node index for the nearest node representing a vertical traversal
     */
    protected int getClosestVerticalTraversal(int safeSurfaceHeight) {
        final int nodesLength = this.currentPath.getLength();

        for (int nodeIndex = this.currentPath.getCurrentNodeIndex(); nodeIndex < nodesLength; nodeIndex++) {
            if (this.currentPath.getNode(nodeIndex).y != safeSurfaceHeight)
                return nodeIndex;
        }

        return nodesLength;
    }
}
